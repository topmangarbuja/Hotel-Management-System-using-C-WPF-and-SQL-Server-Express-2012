﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using System.Collections.ObjectModel;

namespace ClassLibrary
{
    public abstract class Service
    {
        private int previousId;
        private int id;
        private string type;
        private decimal price;
        private string description;

        public int PreviousId
        {
            get { return previousId; }
            set { previousId = value; }
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Type
        {
            get { return type; }
            set { type = value.Trim(); }
        }

        public decimal Price
        {
            get { return price; }
            set { price = value; }
        }

        public string Description
        {
            get { return description; }
            set
            {
                if (string.IsNullOrEmpty(value.Trim()))
                    description = "-";
                else
                    description = value.Trim();
            }
        }
    }
}
