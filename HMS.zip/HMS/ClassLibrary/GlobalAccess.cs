﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Configuration;

namespace ClassLibrary
{
    public abstract class GlobalAccess
    {

        public static string staffId;
        public static string Username;
        public static bool IsLogin;
        public static bool IsPasswordCorrect;
        public static bool IsManager;
        private static string startupPath = AppDomain.CurrentDomain.BaseDirectory;
        public static string reportPath = ConfigurationManager.AppSettings["reportPath"];

        public static string SuccessfulMessage()
        {
            return "Succeed | ";
        }

        public static string ErrorMessage()
        {
            return "Error | ";
        }
    }
}
