﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System.Data;
using System.Data.SqlClient;
using System.Collections.ObjectModel;


namespace ClassLibrary
{
    public class Bill:Booking
    {
        private string billId;

        public string BillId
        {
            get { return billId; }
            set
            {
                if (string.IsNullOrEmpty(value.Trim()))
                    billId = "-";
                else
                    billId = value.Trim();
            }
        }

        private string remarks;
        public string Remarks
        {
            get { return remarks; }
            set
            {
                if (string.IsNullOrEmpty(value.Trim()))
                    remarks = "-";
                else
                    remarks = value.Trim();
            }
        }

        private DateTime checkOutDate;
        public DateTime CheckOutDate
        {
            get { return checkOutDate; }
            set { checkOutDate = value; }
        }

        public void Add()
        {
            SqlCommand command = new SqlCommand();
            /*
            command.CommandText = @"MERGE INTO BILL AS TGT
                                    USING BOOK AS SRC
                                    ON TGT.billId=SRC.bookId 
                                    WHEN MATCHED THEN 
                                    UPDATE SET
                                    TGT.customerId=SRC.customerId,TGT.roomNo=SRC.roomNo,
                                    TGT.foodServiceid=SRC.foodServiceId,TGT.roomServiceId=SRC.roomServiceId,
                                    TGT.noOfPeople=SRC.noOfPeople,TGT.checkInDate=SRC.checkInDate,
                                    TGT.checkOutDate=@checkOutDate,TGT.description=SRC.description,TGT.total=SRC.total,
                                    TGT.remarks=@remarks,TGT.staffId=SRC.staffId
                                    WHEN NOT MATCHED THEN
                                    INSERT(billId,customerId,roomNo,foodServiceId,roomServiceId,noOfPeople,
                                    checkInDate,checkOutDate,description,total,remarks,staffId)
                                    VALUES(SRC.bookId,SRC.customerId,SRC.roomNo,SRC.foodServiceId,SRC.roomServiceId,SRC.noOfPeople,
                                    SRC.checkInDate,@checkOutDate,SRC.description,SRC.total,@remarks,SRC.staffId);";
             */
 
            command.CommandText=@"INSERT INTO BILL(billId,customerId,roomNo,foodServiceId,roomServiceId,noOfPeople,
                                                        checkInDate,checkOutDate,description,total,remarks,staffId)
                                  VALUES(@billId,@customerId,@roomNo,@foodServiceId,@roomServiceId,@noOfPeople,
                                    @checkInDate,@checkOutDate,@description,@total,@remarks,@staffId);
                                  DELETE FROM BOOK
                                  WHERE bookId=@billId;";

            SqlParameter[] param = new SqlParameter[]{              
                new SqlParameter("@billId",BillId),
                new SqlParameter("@customerId",Customer.Id),
                new SqlParameter("@roomNo",Room.RoomNo),
                new SqlParameter("@foodServiceId",FoodService.Id),
                new SqlParameter("@roomServiceId",RoomService.Id),
                new SqlParameter("@noOfPeople",NoOfPeople),
                new SqlParameter("@checkInDate",CheckInDate),
                new SqlParameter("@checkOutDate",CheckOutDate),
                new SqlParameter("@description",Description),
                new SqlParameter("@total",Total),                
                new SqlParameter("@remarks",Remarks),
                new SqlParameter("@staffId",Staff.Id)
            };

            command.Parameters.AddRange(param);

            DBAccess.Insert(command);
        }


        public static string GetNewId()
        {
            SqlCommand command;

            command = new SqlCommand();
            command.CommandText = "SELECT MAX(billId) FROM BILL;";
            DBAccess.Select(command);

            int a;
            if (DBAccess.DataTable.Rows[0][0] != Convert.DBNull)
                a = Convert.ToInt32(DBAccess.DataTable.Rows[0][0].ToString().Substring(2));
            else
                a = 0;

            command = new SqlCommand();
            command.CommandText = "SELECT MAX(bookId) FROM BOOK;";
            DBAccess.Select(command);

            int b;
            if (DBAccess.DataTable.Rows[0][0] != Convert.DBNull)
                b = Convert.ToInt32(DBAccess.DataTable.Rows[0][0].ToString().Substring(2));
            else
                b = 0;


            int no;
            if (a > b)
                no = a;
            else if (a < b)
                no = b;
            else
                return "B-000001";


            no = no + 1;
            string newId = "B-" + no.ToString().PadLeft(5, '0');
            return newId;
        }
    }
}
