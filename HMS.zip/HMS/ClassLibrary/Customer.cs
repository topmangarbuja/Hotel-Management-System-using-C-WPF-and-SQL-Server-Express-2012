﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;
using System.Collections.ObjectModel;

namespace ClassLibrary
{
    public class Customer:Individual,IDBManipulate
    {
      
        public string Name
        {
            get { return FirstName + " " + LastName;}
        }
                
        private static ObservableCollection<Customer> _customers;

        private static ObservableCollection<Customer> GetCustomers()
        {
            SqlCommand command = new SqlCommand();
            command.CommandText = @"SELECT customerID,firstName,lastName,gender,address,phoneNumber,emailAddress
                                  FROM CUSTOMER;";
            DBAccess.Select(command);

            ObservableCollection<Customer> list = new ObservableCollection<Customer>();

            foreach (DataRow item in DBAccess.DataTable.Rows)
            {
                Customer customer = new Customer()
                {
                    Id = item["customerID"].ToString(),
                    FirstName = item["firstName"].ToString(),
                    LastName = item["lastName"].ToString(),
                    Gender = item["gender"].ToString(),
                    Address = item["address"].ToString(),
                    PhoneNumber = item["phoneNumber"].ToString(),
                    EmailAddress = item["emailAddress"].ToString()
                };
                list.Add(customer);
            }
            
            return list;

        }

        public void View()
        {
            _customers = GetCustomers();
        }

        public static ObservableCollection<Customer> Collection
        {
            get
            {
                return _customers;
            }
        }
        
        public void Add()
        {
            SqlCommand command = new SqlCommand();

            command.CommandText = "INSERT INTO CUSTOMER(customerId,firstName,lastName,gender,address,phoneNumber,emailAddress) " +
                "VALUES(@customerId,@firstName,@lastName,@gender,@address,@phoneNumber,@emailAddress);";

            SqlParameter[] a = new SqlParameter[]
            {
               new SqlParameter("@customerId",Id),               
               new SqlParameter("@firstName",FirstName),
               new SqlParameter("@lastName",LastName),               
               new SqlParameter("@gender",Gender),
               new SqlParameter("@address",Address),
               new SqlParameter("@phoneNumber",PhoneNumber),
               new SqlParameter("@emailAddress",EmailAddress)             
            };

           
            command.Parameters.AddRange(a);
            DBAccess.Insert(command);
        }

        public void Update()
        {
            SqlCommand command = new SqlCommand();
            command.CommandText = @"UPDATE CUSTOMER 
                                  SET customerId=@customerId,firstName=@firstName,lastName=@lastName,gender=@gender,address=@address,phoneNumber=@phoneNumber,
                                  emailAddress=@emailAddress
                                  WHERE customerId=@previousCustomerId";

            SqlParameter[] a = new SqlParameter[]
            {
               new SqlParameter("@customerId",Id),               
               new SqlParameter("@firstName",FirstName),
               new SqlParameter("@lastName",LastName),               
               new SqlParameter("@gender",Gender),
               new SqlParameter("@address",Address),
               new SqlParameter("@phoneNumber",PhoneNumber),
               new SqlParameter("@emailAddress",EmailAddress),
               new SqlParameter("@previousCustomerId",PreviousID) 
            };


            command.Parameters.AddRange(a);
            DBAccess.Update(command);
        }

        public void Delete()
        {
            SqlCommand command = new SqlCommand();
            command.CommandText = @"DELETE FROM CUSTOMER                                   
                                  WHERE customerId=@customerId";

            command.Parameters.AddWithValue("@customerId", Id);                        
            DBAccess.Delete(command);
        }
        
    }
}
