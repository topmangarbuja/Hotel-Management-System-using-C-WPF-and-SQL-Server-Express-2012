﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;
using System.Collections.ObjectModel;

namespace ClassLibrary
{
    public class RoomService:Service,IDBManipulate
    {
        private static ObservableCollection<RoomService> _roomservices;


        public void View()
        {
            _roomservices = GetRoomServices();
        }


        
        private static ObservableCollection<RoomService> GetRoomServices()
        {
            SqlCommand command = new SqlCommand();
            command.CommandText = @"SELECT id,type,price,description 
                                  FROM ROOMSERVICE;";
            DBAccess.Select(command);

            ObservableCollection<RoomService> list = new ObservableCollection<RoomService>();

            foreach (DataRow item in DBAccess.DataTable.Rows)
            {
                RoomService roomService = new RoomService()
                {
                    Id = Convert.ToInt32(item["id"].ToString()),
                    Type = item["type"].ToString(),
                    Price = Convert.ToDecimal(item["price"].ToString()),
                    Description = item["description"].ToString()
                };

                list.Add(roomService);

            }
            return list;
        }

        public static ObservableCollection<RoomService> Collection
        {
            get { return _roomservices; }
        }



        public void Add()
        {
            SqlCommand command = new SqlCommand();
            command.CommandText = @"INSERT INTO ROOMSERVICE(id,type,price,description)
                                  VALUES(@id,@type,@price,@description);";

            SqlParameter[] param = new SqlParameter[]
            {
                new SqlParameter("@id",Id),
                new SqlParameter("@type",Type),
                new SqlParameter("@price",Price),
                new SqlParameter("@description",Description)
            };

            command.Parameters.AddRange(param);

            DBAccess.Insert(command);
        }


        public void Update()
        {
            SqlCommand command = new SqlCommand();
            command.CommandText = @"UPDATE ROOMSERVICE 
                                  SET id=@id, type=@type,price=@price,description=@description 
                                  WHERE id=@previousId;";
            SqlParameter[] param = new SqlParameter[]
            {
                 new SqlParameter("@id",Id),
                new SqlParameter("@type",Type),
                new SqlParameter("@price",Price),
                new SqlParameter("@description",Description),
                new SqlParameter("@previousId",PreviousId)
            };

            command.Parameters.AddRange(param);

            DBAccess.Update(command);
        }


        public void Delete()
        {
            SqlCommand command = new SqlCommand();
            command.CommandText = @"DELETE FROM ROOMSERVICE 
                                  WHERE id=@id";

            command.Parameters.AddWithValue("@id", Id);

            DBAccess.Delete(command);

        }


        public int GetNewId()
        {
            View();

            var filtered = Collection.OrderByDescending(x => x.Id).First();
            int id;

            if (filtered != null)
            {
                RoomService rs = filtered as RoomService;
                id = rs.Id + 1;
                return id;
            }
            else
                return 1;
            
        }        

    }
}
