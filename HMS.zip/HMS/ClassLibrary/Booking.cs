﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ClassLibrary
{
    public abstract class Booking
    {        
        public Customer Customer
        { get; set; }

        public Room Room
        {
            get;
            set;
        }

        public FoodService FoodService
        { get; set; }

        public RoomService RoomService
        { get; set; }

        public Staff Staff
        { get; set; }


        private int noOfPeople;
        public int NoOfPeople
        {
            get { return noOfPeople; }
            set { noOfPeople = value; }
        }


        private DateTime checkInDate;
        public DateTime CheckInDate
        {
            get { return checkInDate; }
            set { checkInDate = value; }
        }

        
        private string description;
        public string Description
        {
            get { return description; }
            set
            {
                if (string.IsNullOrEmpty(value.Trim()))
                    description = "-";
                else
                    description = value.Trim();
            }
        }

        private decimal total;
        public decimal Total
        {
            get { return total; }
            set
            {
                if (string.IsNullOrEmpty(value.ToString().Trim()))
                    total = 0;
                else
                    total = value;

            }
        }        
    }
}
