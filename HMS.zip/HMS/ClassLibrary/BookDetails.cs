﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//using System.Data;
//using System.Data.SqlClient;
//using System.Collections.ObjectModel;

//namespace ClassLibrary
//{
//    public class BookDetails
//    {
//        public Customer Customer { get; set; }


//        public Room Room
//        {
//            get;
//            set;
//        }

//        public RoomService RoomService
//        { get; set; }


//        private int noOfdays;
//        public int NoOfDays
//        {
//            get { return noOfdays; }
//            set { noOfdays = value; }
//        }

//        private DateTime checkInDate;
//        public string CheckInDate
//        {
//            get { return checkInDate.ToShortDateString(); }
//            set { checkInDate = Convert.ToDateTime(value); }
//        }
        

        
//        public void Add()
//        {
//            SqlCommand command = new SqlCommand();
        
//            command.CommandText = @"MERGE INTO BOOKDETAILS AS TGT
//                                    USING (SELECT @customerId,@roomNo) AS SRC(custId,roomNo)
//                                    ON TGT.customerId=SRC.custId AND TGT.roomNo=SRC.roomNo
//                                    WHEN MATCHED THEN 
//                                    UPDATE SET
//                                    TGT.checkInDate=@checkInDate,TGT.noOfDays=@noOfDays,TGT.roomServiceId=@roomServiceId
//                                    WHEN NOT MATCHED THEN
//                                    INSERT(customerId,roomNo,checkInDate,noOfDays,roomServiceId)
//                                    VALUES(@customerId,@roomNo,@checkInDate,@noOfDays,@roomServiceId);";

//            SqlParameter[] param = new SqlParameter[]{
//                new SqlParameter("@customerId",Customer.CustomerID),
//                new SqlParameter("@roomNo",Room.RoomNo),
//                new SqlParameter("@checkInDate",CheckInDate),
//                new SqlParameter("@noOfDays",NoOfDays),
//                new SqlParameter("@roomServiceId",RoomService.Id),                                
//            };

//            command.Parameters.AddRange(param);

//            DBAccess.Insert(command);
//        }
        
        
//        public static ObservableCollection<Staff> GetStaffs()
//        {
//            SqlCommand command = new SqlCommand();
//            command.CommandText = @"SELECT customerId,roomNo,checkInDate,noOfDays,roomServiceId
//                                FROM BOOKDETAILS AS BD
//                                INNER JOIN ROOM AS R ON BD.roomNo=R. ";

//            DBAccess.Select(command);

//            ObservableCollection<Staff> list = new ObservableCollection<Staff>();
//            foreach (DataRow item in DBAccess.DataTable.Rows)
//            {
//                //grdStaff.Items.Add(item["staffId"],item["pword"],item["firstName"],item["lastName"],item["dateOfBirth"],item["gender"],
//                //  item["phoneNumber"],item["emailAddress"],item["dateOfJoin"],item["dateOfLeave"],item["isManager"],item["isLogin"]);
//                BookDetails staff = new BookDetails()
//                {
//                    Customer = new Customer() { CustomerID = item["customerId"].ToString()},
//                    Room = new Room() { RoomNo = Convert.ToInt32(item["roomNo"].ToString()), Type = txtRoomType.Text },
//                    CheckInDate = item["checkInDate"].ToString(),
//                    NoOfDays =Convert.ToInt32(item["noOfDays"].ToString()),
//                    RoomService = new RoomService() { Id = Convert.ToInt32(item["roomServiceId"].ToString()), Type = txtRoomServiceType.Text },                                
//                };

//                //list.Add(staff);
//            }
//            return list;
//        }


//        private static ObservableCollection<Staff> _bookDetails;

//        public static ObservableCollection<Staff> Collection
//        {
//            get { return _bookDetails; }
//        }


//    }
//}
