﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;
using System.Collections.ObjectModel;

namespace ClassLibrary
{
    public class FoodService:Service,IDBManipulate
    {
        private static ObservableCollection<FoodService> _foodServices;

        private static ObservableCollection<FoodService> GetFoodServices()
        {
            SqlCommand command = new SqlCommand();
            command.CommandText = @"SELECT id,type,price,description 
                                  FROM FOODSERVICE;";
            DBAccess.Select(command);

            ObservableCollection<FoodService> list = new ObservableCollection<FoodService>();

            foreach (DataRow item in DBAccess.DataTable.Rows)
            {
                FoodService foodService = new FoodService()
                {
                    Id = Convert.ToInt32(item["id"].ToString()),
                    Type = item["type"].ToString(),
                    Price = Convert.ToDecimal(item["price"].ToString()),
                    Description = item["description"].ToString()
                };

                list.Add(foodService);

            }
            return list;
        }

        public static ObservableCollection<FoodService> Collection
        {
            get { return _foodServices; }
        }


        public void View()
        {
            _foodServices = GetFoodServices();
        }

        
        public void Add()
        {
            SqlCommand command = new SqlCommand();
            command.CommandText = @"INSERT INTO FOODSERVICE(id,type,price,description)
                                  VALUES(@id,@type,@price,@description);";

            SqlParameter[] param = new SqlParameter[]
            {
                new SqlParameter("@id",Id),
                new SqlParameter("@type",Type),
                new SqlParameter("@price",Price),
                new SqlParameter("@description",Description)
            };

            command.Parameters.AddRange(param);

            DBAccess.Insert(command);
        }


        public void Update()
        {
            SqlCommand command = new SqlCommand();
            command.CommandText = @"UPDATE FOODSERVICE 
                                  SET id=@id, type=@type,price=@price,description=@description 
                                  WHERE id=@previousId;";
            SqlParameter[] param = new SqlParameter[]
            {
                 new SqlParameter("@id",Id),
                new SqlParameter("@type",Type),
                new SqlParameter("@price",Price),
                new SqlParameter("@description",Description),
                new SqlParameter("@previousId",PreviousId)
            };

            command.Parameters.AddRange(param);

            DBAccess.Update(command);
        }


        public void Delete()
        {
            SqlCommand command = new SqlCommand();
            command.CommandText = @"DELETE FROM FOODSERVICE 
                                  WHERE id=@id";

            command.Parameters.AddWithValue("@id", Id);

            DBAccess.Delete(command);

        }



        public int GetNewId()
        {
            View();

            var filtered = Collection.OrderByDescending(x => x.Id).First();
            int id;
            if (filtered != null)
            {
                FoodService fs = filtered as FoodService;
                id = fs.Id + 1;
                return id;
            }
            else
                return 1;
            
        }        

    }
}
