﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;
using System.Collections.ObjectModel;


namespace ClassLibrary
{
    public class Book:Booking
    {
        private string bookId;

        public string BookID
        {
            get { return bookId; }
            set
            {
                if (string.IsNullOrEmpty(value.Trim()))
                    bookId = "-";
                else
                    bookId = value.Trim();
            }
        }         

        private int noOfdays;
        public int NoOfDays
        {
            get { return noOfdays; }
            set { noOfdays = value; }
        }
    

        private decimal advanced;
        public decimal Advanced
        {
            get { return advanced; }
            set
            {
                if (string.IsNullOrEmpty(value.ToString().Trim()))
                    advanced = 0;
                else
                    advanced = value;

            }
        }

        

        public void Add()
        {
            SqlCommand command = new SqlCommand();
            command.CommandText = @"MERGE INTO BOOK AS TGT
                                    USING (SELECT @bookId) AS SRC(bookId)
                                    ON TGT.bookId=SRC.bookId 
                                    WHEN MATCHED THEN 
                                    UPDATE SET
                                    TGT.customerId=@customerId,TGT.roomNo=@roomNo,
                                    TGT.foodServiceid=@foodServiceId,TGT.roomServiceId=@roomServiceId,
                                    TGT.noOfPeople=@noOfPeople,TGT.checkInDate=@checkInDate,
                                    TGT.noOfDays=@noOfDays,TGT.description=@description,TGT.total=@total,
                                    TGT.advanced=@advanced,TGT.staffId=@staffId
                                    WHEN NOT MATCHED THEN
                                    INSERT(bookId,customerId,roomNo,foodServiceId,roomServiceId,noOfPeople,
                                    checkInDate,noOfDays,description,total,advanced,staffId)
                                    VALUES(@bookId,@customerId,@roomNo,@foodServiceId,@roomServiceId,@noOfPeople,
                                    @checkInDate,@noOfDays,@description,@total,@advanced,@staffId);";

            SqlParameter[] param = new SqlParameter[]{
                new SqlParameter("@bookId",BookID),
                new SqlParameter("@customerId",Customer.Id),
                new SqlParameter("@roomNo",Room.RoomNo),
                new SqlParameter("@foodServiceId",FoodService.Id),
                new SqlParameter("@roomServiceId",RoomService.Id),
                new SqlParameter("@noOfPeople",NoOfPeople),
                new SqlParameter("@checkInDate",CheckInDate),
                new SqlParameter("@noOfDays",NoOfDays),
                new SqlParameter("@description",Description),
                new SqlParameter("@total",Total),
                new SqlParameter("@advanced",Advanced),
                new SqlParameter("@staffId",Staff.Id)
            };

            command.Parameters.AddRange(param);

            DBAccess.Insert(command);
            
        }

        public void View()
        {
            _books = GetBooks();
        }

        public void Delete()
        {
            SqlCommand command = new SqlCommand();
            command.CommandText = @"DELETE FROM BOOK
                                    WHERE bookId=@bookId;";

            command.Parameters.AddWithValue("@bookId",BookID);
            DBAccess.Delete(command);
     
        }

        public static ObservableCollection<Book> GetBooks()
        {
            SqlCommand command = new SqlCommand();
            command.CommandText = @"SELECT B.bookId,C.customerId,C.firstName, C.lastName,R.roomNo,R.type as roomType,RS.id as rsId,Rs.type as rsType,
                                    FS.id as fsId,Fs.type as fsType, 
                                    B.noOfPeople,B.checkIndate,B.noOfDays,B.description,B.total,B.advanced,B.staffId
                                    FROM BOOK AS B
                                    INNER JOIN CUSTOMER AS C ON B.customerId=C.customerID
                                    INNER JOIN ROOM AS R ON B.roomNo=R.roomNo
                                    INNER JOIN ROOMSERVICE AS RS ON B.roomServiceId=RS.id
                                    INNER JOIN FOODSERVICE AS FS ON B.foodServiceId=FS.id;";

            DBAccess.Select(command);

            ObservableCollection<Book> list = new ObservableCollection<Book>();
            foreach (DataRow item in DBAccess.DataTable.Rows)
            {
                 Book book= new Book()
                {
                    bookId=item["bookId"].ToString(),
                    Customer = new Customer() { Id = item["customerId"].ToString(),FirstName= item["firstName"].ToString(),LastName=item["lastName"].ToString()},
                    Room = new Room() { RoomNo = Convert.ToInt32(item["roomNo"].ToString()), Type =item["roomtype"].ToString()},
                    RoomService=new RoomService(){Id=Convert.ToInt32(item["rsId"].ToString()),Type=item["rsType"].ToString()},
                    FoodService = new FoodService() { Id = Convert.ToInt32(item["fsId"].ToString()), Type = item["fsType"].ToString() },
                    CheckInDate =Convert.ToDateTime(item["checkInDate"]),
                    NoOfDays =Convert.ToInt32(item["noOfDays"].ToString()),
                    NoOfPeople=Convert.ToInt32(item["noOfPeople"].ToString()),
                    Description=item["description"].ToString(),
                    Total=Convert.ToDecimal(item["total"].ToString()),
                    advanced=Convert.ToDecimal(item["advanced"].ToString()),
                    Staff=new Staff(){Id=item["staffId"].ToString()},                    
                };                
                
                list.Add(book);
            }
            return list;
        }

        private static ObservableCollection<Book> _books;

        public static ObservableCollection<Book> Collection
        {
            get { return _books; }
        }
    }
}
