﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;
using System.Collections.ObjectModel;

namespace ClassLibrary
{
    public class Staff:Individual,IDBManipulate
    {
        private string staffId;
        private string password;
        private DateTime dateOfBirth;
        public DateTime dateOfJoin;
        public DateTime? dateOfLeave;
        
        public string Password
        {
            get { return password; }
            set 
            {
                if (string.IsNullOrEmpty(value.Trim()))
                    password = "-";
                else
                    password = value.Trim();
            }
        }

        public DateTime DateOfBirth
        { get; set; }

        public string DateOfJoin
        {
            get { return dateOfJoin.ToShortDateString();  }            
        }

        public string DateOfLeave
        {
            get
            {
                if (dateOfLeave.HasValue)
                    return Convert.ToDateTime(dateOfLeave).ToString("MM/dd/yyyy");
                else
                    return dateOfLeave.ToString();
            }
        }

       


        public bool IsManager
        { get; set; }

        public bool IsLogin
        { get; set; }

        public void Add()
        {
            SqlCommand command = new SqlCommand();

            command.CommandText = "INSERT INTO STAFF(staffId,pword,firstName,lastName,dateOfBirth,gender,address,phoneNumber,emailAddress, dateOfJoin,isManager, isLogin) " +
                "VALUES(@staffId,@pword,@firstName,@lastName,@dateOfBirth,@gender,@address,@phoneNumber,@emailAddress, @dateOfJoin,@isManager, @isLogin)";
  
           SqlParameter[] a = new SqlParameter[]
            {
               new SqlParameter("@staffId",Id),
               new SqlParameter("@pword",Password),
               new SqlParameter("@firstName",FirstName),
               new SqlParameter("@lastName",LastName),
               new SqlParameter("@dateOfBirth",DateOfBirth),
               new SqlParameter("@gender",Gender),
               new SqlParameter("@address",Address),
               new SqlParameter("@phoneNumber",PhoneNumber),
               new SqlParameter("@emailAddress",EmailAddress),
               new SqlParameter("@dateOfJoin",DateOfJoin),
               new SqlParameter("@isManager",IsManager),
               new SqlParameter("@isLogin",IsLogin)               
            };
            
            /*
            command.Parameters.AddWithValue("@staffId",StaffID);
            command.Parameters.AddWithValue("@pword", Password);
            command.Parameters.AddWithValue("@firstName",FirstName);
            command.Parameters.AddWithValue("@lastName",LastName);
            command.Parameters.AddWithValue("@dateOfBirth",DateOfBirth);
            command.Parameters.AddWithValue("@gender",Gender);
            command.Parameters.AddWithValue("@phoneNumber",PhoneNumber);
            command.Parameters.AddWithValue("@emailAddress",EmailAdress);
            command.Parameters.AddWithValue("@dateOfJoin",DateOfJoin);
            command.Parameters.AddWithValue("@isManager",IsManager);
            command.Parameters.AddWithValue("@isLogin", IsLogin);
             */

           command.Parameters.AddRange(a);
            DBAccess.Insert(command);
        }

        public void Update()
        {
            SqlCommand command = new SqlCommand();
            command.CommandText = @"UPDATE STAFF 
                                  SET staffId=@staffID,pword=@pword,firstName=@firstName,lastName=@lastName,dateOfBirth=@dateOfBirth,gender=@gender,address=@address,
                                  phoneNumber=@phoneNumber,emailAddress=@emailAddress,dateOfJoin=@dateOfJoin,dateOfLeave=@dateOfLeave,isManager=@isManager,isLogin=@isLogin
                                  WHERE staffId=@originalID";

            SqlParameter[] a = new SqlParameter[]
            {
               new SqlParameter("@staffId",Id),                 
               new SqlParameter("@pword",Password),
               new SqlParameter("@firstName",FirstName),
               new SqlParameter("@lastName",LastName),
               new SqlParameter("@dateOfBirth",DateOfBirth),
               new SqlParameter("@gender",Gender),
                new SqlParameter("@address",Address),
               new SqlParameter("@phoneNumber",PhoneNumber),
               new SqlParameter("@emailAddress",EmailAddress),
               new SqlParameter("@dateOfJoin",DateOfJoin),    
               new SqlParameter("@dateOfLeave", dateOfLeave ?? Convert.DBNull),
               new SqlParameter("@isManager",IsManager),
               new SqlParameter("@isLogin",IsLogin),
               new SqlParameter("@originalID",PreviousID)
            };
            
            command.Parameters.AddRange(a);
            DBAccess.Update(command);
        }

        public void View()
        {           
                _staffs=GetStaffs();
        }

        public void Delete()
        {
            SqlCommand command = new SqlCommand();
            command.CommandText = @"DELETE FROM STAFF 
                                  WHERE staffId=@staffID";

            command.Parameters.AddWithValue("@staffID", Id);

            DBAccess.Delete(command);

        }

     

        public static ObservableCollection<Staff> GetStaffs()
        {
            SqlCommand command = new SqlCommand();
            command.CommandText = @"SELECT staffId,pword,firstName,lastName,dateOfBirth,gender,address, phoneNumber,emailAddress,dateOfJoin,dateOfLeave,isManager,isLogin 
                                FROM STAFF;";

            DBAccess.Select(command);

            ObservableCollection<Staff> list = new ObservableCollection<Staff>();
            foreach (DataRow item in DBAccess.DataTable.Rows)
            {
                //grdStaff.Items.Add(item["staffId"],item["pword"],item["firstName"],item["lastName"],item["dateOfBirth"],item["gender"],
                    //  item["phoneNumber"],item["emailAddress"],item["dateOfJoin"],item["dateOfLeave"],item["isManager"],item["isLogin"]);
                Staff staff=new Staff()
                {
                    Id=item["staffId"].ToString(),
                    Password=item["pword"].ToString(),
                    FirstName=item["firstName"].ToString(),
                    LastName=item["lastName"].ToString(),
                    DateOfBirth=Convert.ToDateTime(item["dateOfBirth"].ToString()),
                    Gender=item["gender"].ToString(),
                    Address=item["address"].ToString(),
                    PhoneNumber=item["phoneNumber"].ToString(),
                    EmailAddress=item["emailAddress"].ToString(),
                    dateOfJoin =Convert.ToDateTime(item["dateOfJoin"].ToString()),   
                    IsManager=Convert.ToBoolean(item["isManager"].ToString()),
                    IsLogin=Convert.ToBoolean(item["isLogin"].ToString())
                };

                if (!DBNull.Value.Equals(item["dateOfLeave"]))
                    staff.dateOfLeave = Convert.ToDateTime(item["dateOfLeave"].ToString());
                    
                list.Add(staff);
            }
            return list;
        }


        private static ObservableCollection<Staff> _staffs;

        public static ObservableCollection<Staff> Collection
        {
            get { return _staffs; }
        }





        public static void Login(string id,string password)
        {
            SqlCommand command = new SqlCommand();
            command.CommandText = @"Select staffId, firstName FROM STAFF 
                                WHERE staffId=@staffId COLLATE SQL_Latin1_General_CP1_CS_AS 
                                AND pword=@pWord COLLATE SQL_Latin1_General_CP1_CS_AS;";
            command.Parameters.AddWithValue("@staffId", id.Trim());
            command.Parameters.AddWithValue("@pWord", password.Trim());            
            DBAccess.Select(command);

            if (!DBAccess.ExceptionExist())    
            {
                if (DBAccess.DataTable.Rows.Count == 1)
                {
                    GlobalAccess.IsPasswordCorrect = true;
                    CanAccess(id);
                }
                else
                    GlobalAccess.IsPasswordCorrect = false;
                    
            }         
         }

        

        private static void CanAccess(string id)
        {
            SqlCommand command = new SqlCommand();
            command.CommandText = @"Select staffId, isManager FROM STAFF 
                                WHERE staffId=@staffId
                                AND isLogin=1;";
            command.Parameters.AddWithValue("@staffId", id);            
            DBAccess.Select(command);

            if (!DBAccess.ExceptionExist())
            {
                if (DBAccess.DataTable.Rows.Count == 1)
                {
                    GlobalAccess.IsLogin = true;
                    GlobalAccess.staffId = DBAccess.DataTable.Rows[0][0].ToString();
                    GlobalAccess.IsManager = Convert.ToBoolean(DBAccess.DataTable.Rows[0][1].ToString());
                }                    
                else
                    GlobalAccess.IsLogin = false;                             
            }
        }
    }
}
