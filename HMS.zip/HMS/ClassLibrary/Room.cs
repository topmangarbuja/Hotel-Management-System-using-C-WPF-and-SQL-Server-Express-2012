﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Data;

namespace ClassLibrary
{
    public class Room:IDBManipulate
    {
        private int roomNo;
        public int RoomNo
        {
            get { return roomNo; }
            set { roomNo = value;}
        }


        private string type;
        public string Type
        {
            get { return type; }
            set { type = value; }
        }
        

        private decimal price;
        public decimal Price
        {
            get { return price; }
            set { price = value; }
        }


        private int previousRoomNo;
        public int PreviousRoomNo
        {
            get { return previousRoomNo; }
            set { previousRoomNo = value; }
        }


        private string description;
        public string Description
        {
            get { return description; }
            set
            {
                if (string.IsNullOrEmpty(value.Trim()))
                    description = "-";
                else
                    description = value.Trim();
            }
        }



        public void Add()
        {
            SqlCommand command = new SqlCommand();
            command.CommandText = @"INSERT INTO ROOM(roomNo,type,price,description)
                                  VALUES(@roomNo,@type,@price,@description);";

            SqlParameter[] param = new SqlParameter[]
            {
                new SqlParameter("@roomNo",RoomNo),
                new SqlParameter("@type",Type),
                new SqlParameter("@price",Price),
                new SqlParameter("@description",Description)
            };

            command.Parameters.AddRange(param);

            DBAccess.Insert(command);
        }

        public void Delete()
        {
            SqlCommand command = new SqlCommand();
            command.CommandText = @"DELETE FROM ROOM 
                                    WHERE roomNo=@roomNo;";
            command.Parameters.AddWithValue("@roomNo", RoomNo);

            DBAccess.Delete(command);

        }

        public void Update()
        {
            SqlCommand command = new SqlCommand();
            command.CommandText = @"UPDATE ROOM 
                                  SET roomNo=@roomNo, type=@type,price=@price,description=@description
                                  WHERE roomNo=@previousRoomNo;";
            SqlParameter[] param = new SqlParameter[]
            {
                new SqlParameter("@roomNo",RoomNo),
                new SqlParameter("@type",Type),
                new SqlParameter("@price",Price),
                new SqlParameter("@description",Description),
                new SqlParameter("@previousRoomNo",PreviousRoomNo)
            };

            command.Parameters.AddRange(param);
            DBAccess.Update(command);
        }

        private static ObservableCollection<Room> _rooms;

        public static ObservableCollection<Room> Collection
        {
            get
            {
               // _rooms = GetRooms();
                return _rooms;
            }

        }  

        private static ObservableCollection<Room> GetRooms()
        {
            SqlCommand command = new SqlCommand();
            command.CommandText = @"SELECT roomNo,type,price,description
                                  FROM ROOM;";
            DBAccess.Select(command);

            ObservableCollection<Room> list = new ObservableCollection<Room>();

            foreach(DataRow item in DBAccess.DataTable.Rows)
            {
                Room room = new Room()
                {
                    RoomNo=Convert.ToInt32(item["roomNo"].ToString()),
                    Type=item["type"].ToString(),
                    Price=Convert.ToDecimal(item["price"].ToString()),
                    Description=item["description"].ToString()

                };

                list.Add(room);
            }

            return list;
        }

        public void View()
        {
            _rooms = GetRooms();
        }

        public void GetAvailableRooms()
        {
            SqlCommand command = new SqlCommand();
            command.CommandText = @"SELECT roomNo,type,price,description
                                  FROM ROOM 
                                  WHERE roomNo NOT IN
                                  (SELECT roomNo
                                  FROM BOOK);";
            DBAccess.Select(command);

            ObservableCollection<Room> list = new ObservableCollection<Room>();

            foreach (DataRow item in DBAccess.DataTable.Rows)
            {
                Room room = new Room()
                {
                    RoomNo = Convert.ToInt32(item["roomNo"].ToString()),
                    Type = item["type"].ToString(),
                    Price = Convert.ToDecimal(item["price"].ToString()),
                    Description = item["description"].ToString()

                };

                list.Add(room);
            }

            _rooms = list;
        }

        public int GetNewRoomNo()
        {
            View();

            var filtered = Collection.OrderByDescending(x => x.roomNo).First();
            int roomNo;

            if (filtered != null)
            {
                Room r = filtered as Room;
                roomNo = r.RoomNo + 1;
                return roomNo;
            }
            else
                return 1;
            
        }                        
        
    }
}