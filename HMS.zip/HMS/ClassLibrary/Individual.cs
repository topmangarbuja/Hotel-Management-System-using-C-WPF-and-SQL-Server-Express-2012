﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public abstract class Individual
    {
        private string id;
        private string previousId;


        public string PreviousID
        {
            get { return previousId; }
            set { previousId = value.Trim(); }
        }
        public string Id
        {
            get { return id; }
            set { id = value.Trim(); }
        }


        private string firstName;
        public string FirstName
        {
            get { return firstName; }
            set { firstName = value.Trim(); }
        }

        private string lastName;
        public string LastName
        {
            get { return lastName; }
            set { lastName = value.Trim(); }
        }

        private string gender;
        public string Gender
        { get; set; }


        private string address;
        public string Address
        {
            get { return address; }
            set
            {
                if (string.IsNullOrEmpty(value.Trim()))
                    address = "-";
                else
                    address = value.Trim();
            }
        }


        private string phoneNumber;
        public string PhoneNumber
        {
            get { return phoneNumber; }
            set
            {
                if (String.IsNullOrEmpty(value.Trim()))
                    phoneNumber = "-";
                else
                    phoneNumber = value;
            }
        }


        private string emailAddress;
        public string EmailAddress
        {
            get { return emailAddress; }
            set
            {
                if (string.IsNullOrEmpty(value.Trim()))
                    emailAddress = "-";
                else
                    emailAddress = value.Trim();
            }
        }
                
        
    }
}
