﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace ClassLibrary
{
    public abstract class DBAccess
    {
        //private static string conString =  @"Data Source=GARBUJA_DBA\SQLEXPRESS;Network Library=DBMSSOCN;" +
          //  "Initial Catalog=HMS;user id=sa;password=winattitude;";
        private static string serverName = ConfigurationManager.AppSettings["server"];
        private static string con = ConfigurationManager.ConnectionStrings["conString"].ToString();
        public static string userId= ConfigurationManager.AppSettings["userId"].ToString();
        public static string password = ConfigurationManager.AppSettings["password"].ToString();
        private static string conString ="Data Source="+serverName+";" +con + "user id=" +userId + "; password="+ password +";";
        private static SqlConnection connection;
        private static SqlCommand command;
        private static SqlDataAdapter dataAdapter;
        private static DataTable dataTable;
        private static Exception error;
        private static string backupPath=ConfigurationManager.AppSettings["backupPath"];
        private static string restorePath=ConfigurationManager.AppSettings["restorePath"];
                

        public static string ServerName
        { get { return serverName; } }
        
        public static string UserId
        {
            get
            {
                return userId;
            }

        }

        public static string Password { get { return password; } }


        public static string BackupPath
        { get { return backupPath; } }

         #region Error Details
        
        /// <summary>
        /// Set the Exception if occur while SELECT,INSERT,UPDATE,SEARCH,DELETE query
        /// </summary>
        private static Exception Error
        {
            get { return error; }
            set { error = value; }
        }

        /// <summary>
        /// Returns the MessageProperty of the exception
        /// </summary>
        public static string ExceptionMessage
        {
            get 
            {
                if (Error != null)
                    return error.Message;
                else
                    return string.Empty;
            }
        }

        /// <summary>
        /// Returns the Exception number if the Exception is SQLException
        /// </summary>
        public static int ExceptionNumber
        {
            get 
            {
                if (error is SqlException)
                {
                    SqlException a = error as SqlException;
                    return a.Number;
                }
                else
                    return 0;
            }
        }

        /// <summary>
        /// Return true or false based on Error occur
        /// </summary>
        /// <returns>Return true if error exist</returns>
        public static bool ExceptionExist()
        {
            if (Error != null)
                return true;
            else
                return false;
        }
        #endregion

        #region Initialize, HasConnection
        /// <summary>
        /// Use to initialize all of the needed reference variables such as of SqlConection, SqlCommand etc.
        /// </summary>
        public static void Initialize()
        {
            connection = new SqlConnection(conString);
            command = new SqlCommand();
            dataAdapter = new SqlDataAdapter();
            dataTable = new DataTable();
        }

        /// <summary>
        /// Check if the connection to the database is ok or not
        /// </summary>
        /// <returns>Return true if connection is successful</returns>
        public static bool HasConnection()
        {
            //Set Error Property to null
            Error = null;

            //Open and close the connection
            try
            {
                connection.Open();
                connection.Close();
                return true;
            }
            catch (Exception err)
            {
                error = err;            //Set ErrorProperty to current error
                connection.Close();
                return false;
            }
        }
        #endregion


        #region Select, DataTable
        /// <summary>
        /// Select any number of rows from database
        /// </summary>
        /// <param name="command">Gets a T-SQL SelectQuery as a SQLCommand</param>
        public static void Select(SqlCommand command)
        {
            //Set Error and DataTable Property to null
            Error = null;
            DataTable = new DataTable();
            
            try 
            {
                connection.Open();
                command.Connection = connection;
                dataAdapter.SelectCommand = command;                  
                dataAdapter.Fill(dataTable);
                connection.Close();
                
            }
            catch(Exception err)
            {
                connection.Close();
                Error = err;
                
            }
        }

        /// <summary>
        /// Property to store and display the rows after SELECT command is executed.
        /// </summary>
        public static DataTable DataTable
        {
            get { return dataTable; }
            set { dataTable = value; }
        }
        #endregion

        #region Insert, Update,Search,Delete,Manipulate
        private static void Manipulate(SqlCommand command)
        {
            //Set Error and DataTable Property to null
            Error = null;
            DataTable = new DataTable();

            //RUN THE QUERY
            try
            {
                connection.Open();
                command.Connection = connection;  //set the connection to SqlConnection
                command.ExecuteNonQuery();        //execute query that doesn't return any row
                connection.Close();
            }
            catch (Exception err)
            {
                Error = err;                       //Set ErrorProperty to current error
                connection.Close();

            }

        }

        /// <summary>
        /// Inserts any number of rows into database
        /// </summary>
        /// <param name="command">Gets a T-SQL InsertQuery as a SQLCommand</param>
        public static void Insert(SqlCommand command)
        {
            Manipulate(command);
        }

        /// <summary>
        /// Update any number of rows of table in a database
        /// </summary>
        /// <param name="command">Gets a T-SQL UpdateQuery as a SQLCommand</param>
        public static void Update(SqlCommand command)
        {
            Manipulate(command);
        }

        /// <summary>
        /// Search any number of rows from tables in a database
        /// </summary>
        /// <param name="command">Gets a T-SQL SearchQuery as a SQLCommand</param>
        public static void Search(SqlCommand command)
        {
            Manipulate(command);
        }

        /// <summary>
        /// Delete any number of rows from a table in a database
        /// </summary>
        /// <param name="command">Gets a T-SQL DeleteQuery as a SQLCommand</param>
        public static void Delete(SqlCommand command)
        {
            Manipulate(command);
        }
        #endregion

        public static void BackupDatabase()
        {
            int year = DateTime.Now.Date.Year;
            int month = DateTime.Now.Date.Month;
            int day = DateTime.Now.Date.Day;

            string backupFolder = backupPath+"\\"+year + "-" + month + "-" + day;
            if (!System.IO.Directory.Exists(backupFolder))
                System.IO.Directory.CreateDirectory(backupFolder);

            SqlCommand command = new SqlCommand();
            command.CommandText="BACKUP DATABASE HMS TO disk= '" + backupFolder + "\\HMS.bak' WITH INIT;";
            Manipulate(command);
        }

        public static void RestoreDatabase(string backupFile)
        {
            SqlCommand command = new SqlCommand();
            command.CommandText = "USE master;ALTER DATABASE HMS " +
                "SET SINGLE_USER " +
                "WITH ROLLBACK IMMEDIATE; " +
                "RESTORE DATABASE  HMS  FROM DISK='" + backupFile + "' " +
                "WITH FILE=1, " +
                "Move N'HMS' TO '" + restorePath + "\\HMS.mdf'," +
                "Move N'HMS_Log'  TO '" + restorePath + "\\HMS_Log.ldf'; " +
                "ALTER DATABASE IcpAdmin SET MULTI_USER;";
            Manipulate(command);
        }

   
    
    }
}