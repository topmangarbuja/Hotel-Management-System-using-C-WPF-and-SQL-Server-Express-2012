﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS
{
    class TextBoxInteger:System.Windows.Controls.TextBox
    {
        protected override void OnKeyDown(System.Windows.Input.KeyEventArgs e)
        {
            base.OnKeyDown(e);

            if (!char.IsNumber((char)e.Key))
                e.Handled = true;
            else
                e.Handled = false;
        }
    }
}
