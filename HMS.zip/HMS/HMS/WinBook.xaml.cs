﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


using System.Collections.ObjectModel;
using CrystalDecisions.CrystalReports.Engine;
using ClassLibrary;

namespace HMS
{
    /// <summary>
    /// Interaction logic for WinBook.xaml
    /// </summary>
    public partial class WinBook : Window
    {
        Book book;
        Book selectedBook;
        Binding binding;
        
        public WinBook()
        {
            InitializeComponent();
            DBAccess.Initialize();
            book = new Book();
            book.View();
            grdBook.ItemsSource = Book.Collection;

            //binding
            binding = new Binding();
            binding.Mode = BindingMode.OneWay;
            binding.Path = new PropertyPath("SelectedValue.BookID");
            binding.ElementName = "grdBook";            
            txtBookId.Text= Bill.GetNewId();        //get new id
                        
            dtpCheckInDate.SelectedDate = DateTime.Today;
        }

        private string SuccessMessage
        {
            get { return GlobalAccess.SuccessfulMessage() + this.Title; }
        }

        private string ErrorMessage
        {
            get { return GlobalAccess.ErrorMessage() + this.Title; }
        }


        private void btnSearchCustomer_Click(object sender, RoutedEventArgs e)
        {
            WinCustomer win = new WinCustomer(true);
            win.ShowDialog();

            if(!string.IsNullOrEmpty(win.CustomerId))
                txtCustomerId.Text = win.CustomerId;

            if(!string.IsNullOrEmpty(win.CustomerName))
                txtCustomerName.Text = win.CustomerName;
        }


        private void btnSearchRoom_Click(object sender, RoutedEventArgs e)
        {
            WinRoom win = new WinRoom(true);
            win.ShowDialog();

            if (!string.IsNullOrEmpty(win.RoomNo))
                txtRoomNo.Text = win.RoomNo;

            if (!string.IsNullOrEmpty(win.RoomType))
                txtRoomType.Text = win.RoomType;
        }

        private void btnSearchFoodService_Click(object sender, RoutedEventArgs e)
        {
            WinFoodService win = new WinFoodService(true);
            win.ShowDialog();
            
            if(!string.IsNullOrEmpty(win.FoodServiceId))
                    txtFoodServiceId.Text = win.FoodServiceId;

            if (!string.IsNullOrEmpty(win.FoodServiceType))
                txtFoodServiceType.Text = win.FoodServiceType;

            
        }

        private void btnSearchRoomService_Click(object sender, RoutedEventArgs e)
        {
            WinRoomService win = new WinRoomService(true);
            win.ShowDialog();

            if(!string.IsNullOrEmpty(win.RoomServiceId))
                txtRoomServiceId.Text = win.RoomServiceId;

            if(!string.IsNullOrEmpty(win.RoomServiceType))
                txtRoomServiceType.Text = win.RoomServiceType;
        }

        private void btnBook_Click(object sender, RoutedEventArgs e)
        {
            if(string.IsNullOrEmpty(txtBookId.Text))
            {
                MessageBox.Show("You should have a book Id. Please click AddNew.", this.Title, MessageBoxButton.OK, MessageBoxImage.Exclamation);
                return;
            }

            DateTime dt = ((DateTime)dtpCheckInDate.SelectedDate).Date + DateTime.Now.TimeOfDay;

            book = new Book()
            {
                BookID=txtBookId.Text,
                Customer=new Customer(){Id=txtCustomerId.Text},
                Room = new Room(){RoomNo=Convert.ToInt32(txtRoomNo.Text),Type=txtRoomType.Text},
                FoodService = new FoodService(){Id=Convert.ToInt32(txtFoodServiceId.Text),Type=txtFoodServiceType.Text},
                RoomService=new RoomService(){Id=Convert.ToInt32(txtRoomServiceId.Text),Type=txtRoomServiceType.Text},
                NoOfPeople=(int)iudNumberOfPeople.Value,
                CheckInDate=dt,
                NoOfDays=(int)iudNoOfDays.Value,
                Description=txtDescription.Text,
                Total=Convert.ToDecimal(txtTotal.Text),
                Advanced=Convert.ToDecimal(txtAdvanced.Text),
                Staff = new Staff() { Id=GlobalAccess.staffId}
            };

            
            //TimeSpan ts =DateTime.Now.TimeOfDay;


            book.Add();
                     
            if (DBAccess.ExceptionExist())
                MessageBox.Show(DBAccess.ExceptionMessage, ErrorMessage, MessageBoxButton.OK, MessageBoxImage.Exclamation);
            else
            {
                foreach(Book b in Book.Collection)
                {
                    if(book.BookID==b.BookID)
                    {
                        Book.Collection.Remove(b);
                        Book.Collection.Add(book);
                        MessageBox.Show("Successfully updated.", SuccessMessage, MessageBoxButton.OK, MessageBoxImage.Information);
                        return;
                    }
                }
                

                Book.Collection.Add(book);
                MessageBox.Show("Successfully booked.", SuccessMessage, MessageBoxButton.OK, MessageBoxImage.Information);

                //get new id
                btnAddNew_Click(null, null);
            }
        }
    

        private void grdBook_Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            Book book = (Book)grdBook.SelectedItem;
            
            if (MessageBox.Show("Are you sure want to delete this currently selected booking details?",
                this.Title, MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                book.Delete();

                if (DBAccess.ExceptionExist())
                    MessageBox.Show(DBAccess.ExceptionMessage, ErrorMessage, MessageBoxButton.OK, MessageBoxImage.Exclamation);
                else
                {
                    Book.Collection.Remove(book);
                    MessageBox.Show("The current booking details have been successfully deleted.", SuccessMessage, MessageBoxButton.OK, MessageBoxImage.Information);
                   
                }

            }
        }

        private void CalculateCost()
        {
            if (!base.IsInitialized) return;

            if (iudNoOfDays.Value == null || iudNumberOfPeople.Value==null ) return;

            if (!string.IsNullOrEmpty(txtRoomNo.Text) && !string.IsNullOrEmpty(txtRoomServiceId.Text) && !string.IsNullOrEmpty(txtFoodServiceId.Text))                
                txtTotal.Text = (FoodCost + RoomCost + RoomServiceCost).ToString();
        }

        private decimal FoodCost
        {
            get
            {
                FoodService fs = new FoodService();
                fs.View();

                var filtered = from FoodService f in FoodService.Collection
                               where f.Id == Convert.ToInt32(txtFoodServiceId.Text)
                               select f;
                
                decimal foodCost = 0M;
                int noOfPeople = (int)iudNumberOfPeople.Value;
                foreach (FoodService f in filtered)
                {
                    foodCost = f.Price;
                    break;
                }

                return (int)iudNoOfDays.Value * foodCost * (int)iudNumberOfPeople.Value;

            }

        }

        private int TotalDays
        {
            get
            {
                int days = (int)iudNoOfDays.Value;               
                return days;
            }
        }

        private decimal RoomCost
        {            
            get
            {
                decimal roomCost = 0M;
                Room room = new Room();
                room.View();
     
                //find room that is on booking list in order to get its price
                    var filtered = from Room r in Room.Collection
                                   where r.RoomNo ==Convert.ToInt32(txtRoomNo.Text)
                                   select r;
                    foreach (Room r in filtered)
                    {
                        roomCost += (r.Price * TotalDays);      //RoomPrice * Corresponding no. of days stayed
                    }
                
                return roomCost;
            }     
        }

        private decimal RoomServiceCost
        {
            get
            {
                decimal cost = 0M;
                RoomService roomService = new RoomService();
                roomService.View();

                    //find room that is on booking list in order to get its price
                    var filtered = from RoomService rs in RoomService.Collection
                                   where rs.Id == Convert.ToInt32(txtRoomServiceId.Text)
                                   select rs;
                    foreach (RoomService rs in filtered)
                    {
                        cost += (rs.Price * TotalDays);      //RoomServicePrice * Corresponding no. of days stayed
                    }
                
                return cost;
            }
        }

        private void txtRoomNo_TextChanged(object sender, TextChangedEventArgs e)
        { 
            CalculateCost();

            GetRemainCost();
        }

        private void iudNumberOfPeople_ValueChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            CalculateCost();
            GetRemainCost();
            
        }

        private void grdBook_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            
                
        }

        private void txtAdvanced_TextChanged(object sender, TextChangedEventArgs e)
        {
            GetRemainCost();
        }

        private void GetRemainCost()
        {
            try
            {
                if (!string.IsNullOrEmpty(txtTotal.Text) && !string.IsNullOrEmpty(txtAdvanced.Text))
                    txtRemain.Text = (Convert.ToDecimal(txtTotal.Text) - Convert.ToDecimal(txtAdvanced.Text)).ToString();
                else
                    txtRemain.Text = string.Empty;
            }
            catch(Exception)
            {
                txtRemain.Text = string.Empty;
            }
            
        }

        private void GetChange()
        {
            try 
            {
                //if (!string.IsNullOrEmpty(txtRemain.Text) && !string.IsNullOrEmpty(txtPayRemain.Text))
                //    txtChange.Text = (Convert.ToDecimal(txtPayRemain.Text) - Convert.ToDecimal(txtRemain.Text)).ToString();
                //else
                //    txtChange.Text = string.Empty;

                if (!string.IsNullOrEmpty(txtPayRemain.Text))
                    txtChange.Text = (Convert.ToDecimal(txtPayRemain.Text) - Convert.ToDecimal(selectedBook.Total -selectedBook.Advanced)).ToString();
                else
                    txtChange.Text = string.Empty;
                txtBookId.SetBinding(TextBox.TextProperty, binding); //bind
            }
            catch(Exception)
            { }
            
        }

        private void txtPayRemain_TextChanged(object sender, TextChangedEventArgs e)
        {
            GetChange();
        }

        private void btnCheckOut_Click(object sender, RoutedEventArgs e)
        {
            bool exist = false;

            foreach(Book b in Book.Collection)
            {
                if (txtBookId.Text == b.BookID)
                    exist = true;
            }

            if(exist==false)
            {
                MessageBox.Show("You can't check-out without booking first.", this.Title, MessageBoxButton.OK, MessageBoxImage.Exclamation);
                return;
            }
                

            if (string.IsNullOrEmpty(txtPayRemain.Text))
            {
                MessageBox.Show("Pay money before Checking-Out.", this.Title, MessageBoxButton.OK, MessageBoxImage.Exclamation);
                return;
            }

            if(MessageBox.Show("Are you sure want to check-out?",this.Title,MessageBoxButton.YesNo,
                MessageBoxImage.Question)!=MessageBoxResult.Yes)
            {
                return;
            }


            //create new bill Details
            Bill bill = new Bill()
            {
                BillId = selectedBook.BookID,
                Customer = new Customer() { Id = selectedBook.Customer.Id },
                Room = new Room() { RoomNo = Convert.ToInt32(selectedBook.Room.RoomNo) },
                FoodService = new FoodService() { Id = Convert.ToInt32(selectedBook.FoodService.Id) },
                RoomService = new RoomService() { Id = Convert.ToInt32(selectedBook.RoomService.Id)},
                NoOfPeople = (int)iudNumberOfPeople.Value,
                CheckInDate = Convert.ToDateTime(dtpCheckInDate.SelectedDate),
                CheckOutDate = DateTime.Now,
                Description = txtDescription.Text,
                Total = Convert.ToDecimal(txtTotal.Text),
                Remarks=txtRemarks.Text,
                Staff = new Staff() { Id=GlobalAccess.staffId }
            };

            //add bills to DB
            bill.Add();

            //show if error exists
            if (DBAccess.ExceptionExist())
                MessageBox.Show(DBAccess.ExceptionMessage, ErrorMessage, MessageBoxButton.OK, MessageBoxImage.Exclamation);
            else
            {
                Decimal ad=Convert.ToDecimal(txtAdvanced.Text);
                Decimal r=Convert.ToDecimal(txtRemain.Text);
                Decimal c=Convert.ToDecimal(txtChange.Text);
                Decimal p=Convert.ToDecimal(txtPayRemain.Text);
                String id = txtBookId.Text;
                                
                Book.Collection.Remove(selectedBook);
                MessageBox.Show("Successfully checked-out.", SuccessMessage, MessageBoxButton.OK, MessageBoxImage.Information);
                
                try
                {
                    ReportDocument report = new ReportDocument();
                    string path = GlobalAccess.reportPath + "\\BillSpecific.rpt";
                    report.Load(path);
                    report.DataSourceConnections[0].SetConnection(DBAccess.ServerName, "HMS", DBAccess.UserId, DBAccess.Password);
                    report.SetDatabaseLogon(DBAccess.UserId, DBAccess.Password);
                    report.VerifyDatabase();
                    report.SetParameterValue("prmAdvanced", ad);
                    report.SetParameterValue("prmRemain", r);
                    report.SetParameterValue("prmChange", c);
                    report.SetParameterValue("prmPayRemain", p);

                    string strSelectFormula = "";
                    strSelectFormula = "{BILL.billId}='" + id + "'";

                    report.RecordSelectionFormula = strSelectFormula;
                    WinReport a = new WinReport();
                    report.DataSourceConnections[0].SetConnection(DBAccess.ServerName, "HMS", DBAccess.UserId, DBAccess.Password);
                    a.CrystalReportsViewer1.ViewerCore.ReportSource = report;
                    a.Show();
                }
                catch(Exception)
                {

                }
                

                //get new id
                btnAddNew_Click(null, null);
            }
        }

        

        private void grdBook_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if(grdBook.SelectedIndex>=0)
            {
                selectedBook = (Book)grdBook.SelectedItem;
                txtBookId.SetBinding(TextBox.TextProperty, binding); //bind
                txtPayRemain.Text = "";
            }
        }

        private void txtCustomerName_Copy_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void txtSearchBookId_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtSearchBookId.Text)) return;

            var filtered = Book.Collection.Where(b => b.BookID.Contains(txtSearchBookId.Text));

            //ObservableCollection<Book> list = filtered as ObservableCollection<Book>;
            grdBook.ItemsSource = filtered;
        }

        private void txtSearchCustomerFirstName_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtSearchCustomerFirstName.Text)) return;

            var filtered = Book.Collection.Where(b => b.Customer.FirstName.Contains(txtSearchCustomerFirstName.Text));

            grdBook.ItemsSource = filtered;
        }

        private void btnView_Click(object sender, RoutedEventArgs e)
        {
            book.View();
            grdBook.ItemsSource = Book.Collection;

        }

        private void dtpSearchCheckInDate_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dtpSearchCheckInDate.SelectedDate == null) return;

            var filtered = Book.Collection.Where(b => b.CheckInDate.Date == dtpSearchCheckInDate.SelectedDate);

            grdBook.ItemsSource = filtered;
        }

        private void txtSearchCustomerId_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtSearchCustomerId.Text)) return;

            var filtered = Book.Collection.Where(b => b.Customer.Id.Contains(txtSearchCustomerId.Text));

            grdBook.ItemsSource = filtered;
        }

        private void txtSearchRoomNo_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtSearchRoomNo.Text)) return;

            var filtered = Book.Collection.Where(b => b.Room.RoomNo.ToString().Contains(txtSearchRoomNo.Text));

            grdBook.ItemsSource = filtered;
        }

        private void btnAddNew_Click(object sender, RoutedEventArgs e)
        {
            txtBookId.Text = Bill.GetNewId();
            selectedBook = null;
        }

        private void chkEnterCheckOut_Click(object sender, RoutedEventArgs e)
        {
            if((bool)chkEnterCheckOut.IsChecked)
            {
                grdCheckOut.Visibility = Visibility.Visible;
            }
            else
            {
                grdCheckOut.Visibility = Visibility.Collapsed;
            }
        }
    }
}
