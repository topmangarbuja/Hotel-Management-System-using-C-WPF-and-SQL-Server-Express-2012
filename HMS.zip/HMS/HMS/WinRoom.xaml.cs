﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using ClassLibrary;


namespace HMS
{
    /// <summary>
    /// Interaction logic for WinRoom.xaml
    /// </summary>
    public partial class WinRoom : Window
    {
        private bool PassValue { get; set; }

        public WinRoom()
        {
            InitializeComponent();
            DBAccess.Initialize();
        }

        public WinRoom(bool passValue)
        {
            InitializeComponent();
            DBAccess.Initialize();

            PassValue = passValue;
        }
        private string SuccessMessage
        {
            get { return GlobalAccess.SuccessfulMessage() + this.Title; }
        }

        private string ErrorMessage
        {
            get { return GlobalAccess.ErrorMessage() + this.Title; }
        }


        public string RoomNo
        {
            get
            {
                if(grdRoom.SelectedIndex>=0)
                {
                    Room room = (Room)grdRoom.SelectedItem;
                    return room.RoomNo.ToString();      
                }
                else
                {
                    return string.Empty;
                }
                
                
            }
        }

        public string RoomType
        {
            get
            {
                if (grdRoom.SelectedIndex >= 0)
                {
                    Room room = (Room)grdRoom.SelectedItem;
                    return room.Type;
                }
                else
                {
                    return string.Empty;
                }
                
            }
        }





        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            WinRoomAdd win = new WinRoomAdd();
            win.ShowDialog();
        }

        private void btnView_Click(object sender, RoutedEventArgs e)
        {
            Room room = new Room();

            if (PassValue)
                room.GetAvailableRooms();
            else
                room.View();

            if(DBAccess.ExceptionExist())
                MessageBox.Show(DBAccess.ExceptionMessage, ErrorMessage, MessageBoxButton.OK, MessageBoxImage.Exclamation);
            else
            {
                grdRoom.ItemsSource = Room.Collection;
            }
                
        }

        private void grdRoom_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if(PassValue)
            {
                this.Close();
                return;
            }

            EditRoom();
        }

        private void EditRoom()
        {
            if (grdRoom.SelectedIndex >= 0)
            {
                Room room = (Room)grdRoom.SelectedItem;
                WinRoomUpdate win = new WinRoomUpdate(room.RoomNo);
                win.ShowDialog();
            }
        }

        private void grdRoom_Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            Room room = (Room)grdRoom.SelectedItem;

            if(MessageBox.Show("Are you sure want to delete this room?",this.Title,MessageBoxButton.YesNo,
                MessageBoxImage.Question)==MessageBoxResult.Yes)
            {
                room.Delete();

                if (DBAccess.ExceptionExist())
                    MessageBox.Show(DBAccess.ExceptionMessage, ErrorMessage, MessageBoxButton.OK, MessageBoxImage.Exclamation);
                else
                {
                    MessageBox.Show("The current room has been successfully deleted.", SuccessMessage, MessageBoxButton.OK, MessageBoxImage.Information);
                    Room.Collection.Remove(room);
                }
            }
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            EditRoom();
        }
    }
}
