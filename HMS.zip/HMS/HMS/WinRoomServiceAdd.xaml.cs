﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


using ClassLibrary;

namespace HMS
{
    /// <summary>
    /// Interaction logic for WinRoomServiceAdd.xaml
    /// </summary>
    public partial class WinRoomServiceAdd : Window
    {
        public WinRoomServiceAdd()
        {
            InitializeComponent();
            RoomService rs = new RoomService();
            txtServiceId.Text = rs.GetNewId().ToString();
        }


        private string SuccessMessage
        {

            get { return GlobalAccess.SuccessfulMessage() + this.Title; }
        }

        private string ErrorMessage
        {
            get { return GlobalAccess.ErrorMessage() + this.Title; }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            RoomService roomService = new RoomService()
            {
                Id = Convert.ToInt32(txtServiceId.Text),
                Type = cboType.Text,
                Price = Convert.ToDecimal(txtPrice.Text),
                Description=txtDescription.Text
            };

            roomService.Add();

            if (DBAccess.ExceptionExist())
                MessageBox.Show(DBAccess.ExceptionMessage, ErrorMessage, MessageBoxButton.OK, MessageBoxImage.Exclamation);
            else
            {
                MessageBox.Show("New room service added successfully.", SuccessMessage, MessageBoxButton.OK, MessageBoxImage.Information);
                RoomService.Collection.Add(roomService);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            foreach (RoomService rs in RoomService.Collection)
            {
                if (!cboType.Items.Contains(rs.Type))
                    cboType.Items.Add(rs.Type);
            }
        }
    }
}
