﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using ClassLibrary;

namespace HMS
{
    /// <summary>
    /// Interaction logic for WinRoomUpdate.xaml
    /// </summary>
    public partial class WinRoomUpdate : Window
    {
        private Room room;
        public WinRoomUpdate(int previousRoomNo)
        {
            InitializeComponent();
            room = new Room();
            room.PreviousRoomNo = previousRoomNo;
        }

        private string SuccessMessage
        {
            get { return GlobalAccess.SuccessfulMessage() + this.Title; }
        }

        private string ErrorMessage
        {
            get { return GlobalAccess.ErrorMessage() + this.Title; }
        }


        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            foreach (Room r in Room.Collection)
            {
                if (!cboType.Items.Contains(r.Type))
                    cboType.Items.Add(r.Type);
            }

            var filtered = from Room r in Room.Collection
                           where r.RoomNo == room.PreviousRoomNo
                           select r;

            foreach(Room r in filtered)
            {
                txtRoomNo.Text = r.RoomNo.ToString();

                cboType.Text=r.Type;

                txtPrice.Text = r.Price.ToString();
                txtDescription.Text = r.Description;
                break;
            }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            room.RoomNo = Convert.ToInt32(txtRoomNo.Text);
            room.Type = cboType.Text;
            room.Price = Convert.ToDecimal(txtPrice.Text);
            room.Description = txtDescription.Text;
            
            room.Update();

            if (DBAccess.ExceptionExist())
                MessageBox.Show(DBAccess.ExceptionMessage, ErrorMessage, MessageBoxButton.OK, MessageBoxImage.Exclamation);
            else
            {
                //Room.Collection.Remove(room);
                MessageBox.Show("The room details updated successfully.", ErrorMessage, MessageBoxButton.OK, MessageBoxImage.Information);                
                //Room.Collection.Add(room);
            }
        }
    }
}
