﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using ClassLibrary;

namespace HMS
{
    /// <summary>
    /// Interaction logic for WinCustomerUpdate.xaml
    /// </summary>
    public partial class WinCustomerUpdate : Window
    {
        private Customer customer;

        public WinCustomerUpdate(string previousCustomerId)
        {
            InitializeComponent();
            customer = new Customer();
            customer.PreviousID = previousCustomerId;
        }

        private string ErrorMessage
        {
            get { return GlobalAccess.ErrorMessage() + this.Title; }
        }

        private string SuccessMessage
        {
            get { return GlobalAccess.SuccessfulMessage() + this.Title; }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var filtered = from Customer c in Customer.Collection
                           where c.Id == customer.PreviousID
                           select c;

            foreach(Customer c in filtered)
            {
                txtCustomerId.Text = c.Id;
                txtFirstName.Text = c.FirstName;
                txtLastName.Text = c.LastName;
                if (c.Gender.ToLower().StartsWith("male"))
                    cboGender.SelectedIndex = 0;
                else
                    cboGender.SelectedIndex = 1;

                txtAddress.Text = c.Address;
                txtPhoneNumber.Text = c.PhoneNumber;
                txtEmailAddress.Text = c.EmailAddress;
                break;
            }
        }


        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {

            customer.Id = txtCustomerId.Text;
            customer.FirstName = txtFirstName.Text;
            customer.LastName = txtLastName.Text;            
            customer.Gender = cboGender.Text;
            customer.Address = txtAddress.Text;
            customer.PhoneNumber = txtPhoneNumber.Text;
            customer.EmailAddress = txtEmailAddress.Text;
            
            customer.Update();

            if (DBAccess.ExceptionExist())
                MessageBox.Show(DBAccess.ExceptionMessage, ErrorMessage, MessageBoxButton.OK, MessageBoxImage.Exclamation);
            else
                MessageBox.Show("The staff data is updated successfully", SuccessMessage, MessageBoxButton.OK, MessageBoxImage.Information);    
        }
    }
}
