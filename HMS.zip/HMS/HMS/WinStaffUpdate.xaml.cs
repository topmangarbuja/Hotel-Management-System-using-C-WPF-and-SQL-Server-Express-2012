﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using ClassLibrary;

namespace HMS
{
    /// <summary>
    /// Interaction logic for WinStaffUpdate.xaml
    /// </summary>
    public partial class WinStaffUpdate : Window
    {
        private Staff staff;
       
        public WinStaffUpdate(string oldStaffId)
        {
            InitializeComponent();
            staff = new Staff();
            staff.PreviousID = oldStaffId;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
             var filtered = from Staff s in Staff.Collection
                                where s.Id==staff.PreviousID
                                select s;
                         
            foreach (Staff st in filtered)
            {
                txtStaffId.Text = st.Id;
                txtFirstName.Text = st.FirstName;
                txtLastName.Text = st.LastName;
                dtpDateOfBirth.DisplayDate = st.DateOfBirth;

                if (st.Gender.StartsWith("Male"))
                    cboGender.SelectedIndex = 0;
                else
                    cboGender.SelectedIndex = 1;

                txtAddress.Text = st.Address;
                txtPhoneNumber.Text = st.PhoneNumber;
                txtEmailAddress.Text = st.EmailAddress;
                dtpDateOfJoin.DisplayDate = st.dateOfJoin;                
                cboUserType.SelectedIndex = Convert.ToInt32(st.IsManager);
                cboLogin.SelectedIndex = Convert.ToInt32(st.IsLogin);
                txtPassword.Text = st.Password;            

                break;
            }            

        }

        public string SuccessMessage
        {
            get
            {
                return GlobalAccess.SuccessfulMessage() + this.Title;
            }
        }

        public string ErrorMessage
        {
            get
            {
                return GlobalAccess.ErrorMessage() + this.Title;
            }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {          
            staff.Id=txtStaffId.Text;
            staff.FirstName = txtFirstName.Text;
            staff.LastName = txtLastName.Text;
            staff.DateOfBirth = dtpDateOfBirth.DisplayDate;              
            staff.Gender = cboGender.Text;
            staff.Address = txtAddress.Text;
            staff.PhoneNumber = txtPhoneNumber.Text;
            staff.EmailAddress=txtEmailAddress.Text;
            staff.dateOfJoin = dtpDateOfJoin.DisplayDate;
            staff.IsManager = Convert.ToBoolean(cboUserType.SelectedIndex);
            staff.IsLogin = Convert.ToBoolean(cboLogin.SelectedIndex);
            staff.Password = txtPassword.Text;

            if (dtpDateOfLeave.SelectedDate.HasValue)
                staff.dateOfLeave = (DateTime)dtpDateOfLeave.SelectedDate;


            staff.Update();

            if (DBAccess.ExceptionExist())
                MessageBox.Show(DBAccess.ExceptionMessage, ErrorMessage, MessageBoxButton.OK, MessageBoxImage.Exclamation);
            else
                MessageBox.Show("The staff data is updated successfully", SuccessMessage, MessageBoxButton.OK, MessageBoxImage.Information);            
        }     
    }
}
