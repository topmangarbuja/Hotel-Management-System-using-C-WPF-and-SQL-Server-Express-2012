﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using ClassLibrary;

namespace HMS
{
    /// <summary>
    /// Interaction logic for WinRoom.xaml
    /// </summary>
    public partial class WinRoomAdd : Window
    {
        public WinRoomAdd()
        {
            InitializeComponent();
            Room room = new Room();
            txtRoomNo.Text=room.GetNewRoomNo().ToString();

            room.View();
        }


        private string SuccessMessage
        {

            get { return GlobalAccess.SuccessfulMessage() + this.Title; }
        }

        private string ErrorMessage
        {
            get { return GlobalAccess.ErrorMessage() + this.Title; }
        }
        
        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            Room room = new Room()
            {
                RoomNo = Convert.ToInt32(txtRoomNo.Text),
                Type = cboType.Text,
                Price = Convert.ToDecimal(txtPrice.Text),
                Description=txtDescription.Text
            };

            room.Add();

            if (DBAccess.ExceptionExist())
                MessageBox.Show(DBAccess.ExceptionMessage, ErrorMessage, MessageBoxButton.OK, MessageBoxImage.Exclamation);
            else
            {
                MessageBox.Show("New room added successfully.", SuccessMessage, MessageBoxButton.OK, MessageBoxImage.Information);
                Room.Collection.Add(room);
            }             
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            foreach(Room r in Room.Collection)
            {
                if(!cboType.Items.Contains(r.Type))
                    cboType.Items.Add(r.Type);
            }
        }
    }
}
