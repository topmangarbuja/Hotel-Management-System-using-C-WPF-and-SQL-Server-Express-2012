﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using ClassLibrary;

namespace HMS
{
    /// <summary>
    /// Interaction logic for WinCustomerAdd.xaml
    /// </summary>
    public partial class WinCustomerAdd : Window
    {
        private Customer customer;
        public WinCustomerAdd()
        {
            InitializeComponent();
            
        }

        private string SuccessMessage
        {
            get { return GlobalAccess.SuccessfulMessage() + this.Title; }
        }

        private string ErrorMessage
        {
            get { return GlobalAccess.ErrorMessage() + this.Title; }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            customer = new Customer()
            {
                Id = txtCustomerId.Text,
                FirstName = txtFirstName.Text,
                LastName = txtLastName.Text,
                Gender = cboGender.Text,
                Address = txtAddress.Text,
                PhoneNumber = txtPhoneNumber.Text,
                EmailAddress = txtEmailAddress.Text
            };

            customer.Add();
            
            if (DBAccess.ExceptionExist())
                MessageBox.Show(DBAccess.ExceptionMessage, ErrorMessage, MessageBoxButton.OK, MessageBoxImage.Exclamation);
            else
            {
                MessageBox.Show("The new customer is successfully added.", SuccessMessage, MessageBoxButton.OK, MessageBoxImage.Information);
                Customer.Collection.Add(customer);
            }
                
    
        }
    }
}
