﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using ClassLibrary;

namespace HMS
{
    /// <summary>
    /// Interaction logic for StaffAdd.xaml
    /// </summary>
    public partial class WinStaffAdd : Window
    {
        public WinStaffAdd()
        {
            InitializeComponent();
            DBAccess.Initialize();
        }            

        private string SuccessMessage
        {
            get
            {
                return GlobalAccess.SuccessfulMessage() + this.Title;
            }            
        }

        private string ErrorMessage
        {
            get
            {
                return GlobalAccess.ErrorMessage() + this.Title;
            }        
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {            
            Staff staff = new Staff()
            {
                Id=txtStaffId.Text,
                FirstName = txtFirstName.Text,
                LastName = txtLastName.Text,
                DateOfBirth =(DateTime)dtpDateOfBirth.SelectedDate,
                Gender = cboGender.Text,
                Address=txtAddress.Text,
                PhoneNumber = txtPhoneNumber.Text,
                EmailAddress = txtEmailAddress.Text,
                dateOfJoin =(DateTime)dtpDateOfJoin.SelectedDate,
                IsManager = Convert.ToBoolean(cboUserType.SelectedIndex),
                IsLogin = Convert.ToBoolean(cboLogin.SelectedIndex),
                Password=txtPassword.Text
            };

            staff.Add();

            if (DBAccess.ExceptionExist())
                MessageBox.Show(DBAccess.ExceptionMessage, ErrorMessage, MessageBoxButton.OK, MessageBoxImage.Exclamation);
            else
            {
                Staff.Collection.Add(staff);
                MessageBox.Show("New staff added successfully", SuccessMessage, MessageBoxButton.OK, MessageBoxImage.Information);            
            }
                
        }
    }
}
