﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using ClassLibrary;

namespace HMS
{
    /// <summary>
    /// Interaction logic for WinRoomService.xaml
    /// </summary>
    public partial class WinRoomService : Window
    {

        private bool PassValue
        { get; set; }

        public WinRoomService()
        {
            InitializeComponent();
            RoomService rs = new RoomService();
            rs.View();
        }

        public WinRoomService(bool passValue)
        {
            InitializeComponent();
            DBAccess.Initialize();
            this.PassValue = passValue;
        }


        public string RoomServiceId
        {
            get
            {
                if (grdRoomService.SelectedIndex >= 0)
                {
                    RoomService roomService = (RoomService)grdRoomService.SelectedItem;
                    return roomService.Id.ToString();
                }
                else
                    return string.Empty;
                
            }
        }

        public string RoomServiceType
        {
            get
            {
                if (grdRoomService.SelectedIndex >= 0)
                {
                    RoomService roomService = (RoomService)grdRoomService.SelectedItem;
                    return roomService.Type;
                }
                else
                    return string.Empty;
            }
        }


        private string SuccessMessage
        {
            get { return GlobalAccess.SuccessfulMessage() + this.Title; }
        }

        private string ErrorMessage
        {
            get { return GlobalAccess.ErrorMessage() + this.Title; }
        }


        private void btnView_Click(object sender, RoutedEventArgs e)
        {
            RoomService roomService = new RoomService();
            roomService.View();

            if (DBAccess.ExceptionExist())
                MessageBox.Show(DBAccess.ExceptionMessage, ErrorMessage, MessageBoxButton.OK, MessageBoxImage.Exclamation);
            else
            {
                //grdStaff.DataContext;
                grdRoomService.ItemsSource = RoomService.Collection;
            }
        }

        private void grdRoomService_Hyperlink_Click(object sender,RoutedEventArgs e)
        {
            RoomService roomService = (RoomService)grdRoomService.SelectedItem;
            //MessageBox.Show(staff.FirstName);

            if (MessageBox.Show("Are you sure want to delete this currently selected room service ?",
                this.Title, MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                roomService.Delete();

                if (DBAccess.ExceptionExist())
                    MessageBox.Show(DBAccess.ExceptionMessage, ErrorMessage, MessageBoxButton.OK, MessageBoxImage.Exclamation);
                else
                {
                    MessageBox.Show("The current room service has been successfully deleted.", SuccessMessage, MessageBoxButton.OK, MessageBoxImage.Information);
                    RoomService.Collection.Remove(roomService);
                }

            }
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            WinRoomServiceAdd win = new WinRoomServiceAdd();
            win.ShowDialog();
        }

        private void grdRoomService_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if(PassValue)
            {
                this.Close();
                return;
            }


            EditRoomService();
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            EditRoomService();
        }

        private void EditRoomService()
        {
            if (grdRoomService.SelectedIndex >= 0)
            {
                RoomService roomService = (RoomService)grdRoomService.SelectedItem;
                WinRoomServiceUpdate win = new WinRoomServiceUpdate(roomService.Id);
                win.ShowDialog();

            }
        }
    }
}
