﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using ClassLibrary;

namespace HMS
{
    /// <summary>
    /// Interaction logic for WinFoodServiceAdd.xaml
    /// </summary>
    public partial class WinFoodServiceAdd : Window
    {
        
        public WinFoodServiceAdd()
        {
            InitializeComponent();  
          FoodService fs=new FoodService();
          txtServiceId.Text = fs.GetNewId().ToString();
        }

        private string SuccessMessage
        {
            get { return GlobalAccess.SuccessfulMessage() + this.Title; }
        }

        private string ErrorMessage
        {
            get { return GlobalAccess.ErrorMessage() + this.Title; }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            FoodService foodService = new FoodService()
            {
                Id = Convert.ToInt32(txtServiceId.Text),
                Type = cboType.Text,
                Price = Convert.ToDecimal(txtPrice.Text),
                Description = txtDescription.Text
            };

            foodService.Add();

            if (DBAccess.ExceptionExist())
                MessageBox.Show(DBAccess.ExceptionMessage, ErrorMessage, MessageBoxButton.OK, MessageBoxImage.Exclamation);
            else
            {
                FoodService.Collection.Add(foodService);
                MessageBox.Show("The food service details have been successfully saved.", SuccessMessage, MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            foreach(FoodService fs in FoodService.Collection)
            {
                if (!cboType.Items.Contains(fs.Type))
                    cboType.Items.Add(fs.Type);
            }
        }
    }
}