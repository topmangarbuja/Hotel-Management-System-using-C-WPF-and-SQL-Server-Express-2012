﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using ClassLibrary;

namespace HMS
{
    /// <summary>
    /// Interaction logic for Main.xaml
    /// </summary>
    public partial class Main : Window
    {
        public Main()
        {
            InitializeComponent();
            DBAccess.Initialize();
            lblStaffId.Content = GlobalAccess.staffId;
        }

        private void menuItemStaff_Click(object sender, RoutedEventArgs e)
        {
            WinStaff win = new WinStaff();
            win.Loaded += win_Loaded;
            win.Closed += win_Closed;
            win.ShowDialog();
        }

        private void menuItemRoom_Click(object sender, RoutedEventArgs e)
        {
            WinRoom win = new WinRoom();
            win.Loaded += win_Loaded;
            win.Closed += win_Closed;
            win.ShowDialog();
        }

        void win_Loaded(object sender, RoutedEventArgs e)
        {
            this.Hide();
        }

        void win_Closed(object sender, EventArgs e)
        {
            this.Show();   
        }

        private void menuItemCustomer_Click(object sender, RoutedEventArgs e)
        {
            WinCustomer win = new WinCustomer();
            win.Loaded += win_Loaded;
            win.Closed += win_Closed;
            win.ShowDialog();
        }

        private void menuItemRoomService_Click(object sender, RoutedEventArgs e)
        {
            WinRoomService win = new WinRoomService();
            win.Loaded += win_Loaded;
            win.Closed += win_Closed;
            win.ShowDialog();
        }

        private void menuItemFoodService_Click(object sender, RoutedEventArgs e)
        {
            WinFoodService win = new WinFoodService();
            win.Loaded += win_Loaded;
            win.Closed += win_Closed;
            win.ShowDialog();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {

            if (MessageBox.Show("Are you sure want to close this application?", this.Title,
               MessageBoxButton.YesNoCancel, MessageBoxImage.Question) != MessageBoxResult.Yes)
            {
                e.Cancel = true;
            }             
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            Application.Current.Shutdown();
            
        }

        private void menuItemBookCheckOut_Click(object sender, RoutedEventArgs e)
        {
            WinBook win = new WinBook();
            win.Loaded += win_Loaded;
            win.Closed += win_Closed;
            win.ShowDialog();
        }

        private void menuItemReports_Click(object sender, RoutedEventArgs e)
        {
            WinReports win = new WinReports();
            
            win.Show();
        }

        private void btnRestore_Click(object sender, RoutedEventArgs e)
        {
            WinRestore win = new WinRestore();
            win.ShowDialog();
        }

        private void btnBackup_Click(object sender, RoutedEventArgs e)
        {
            DBAccess.BackupDatabase();
            
            if (DBAccess.ExceptionExist())
            {
                MessageBox.Show(DBAccess.ExceptionMessage, "Error | " + this.Title, MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                MessageBox.Show("Successfully backup.", this.Title, MessageBoxButton.OK, MessageBoxImage.Information);

            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if(!GlobalAccess.IsManager)
            {
                menuItemSettings.Visibility = Visibility.Collapsed;
                menuItemStaff.Visibility = Visibility.Collapsed;
            }
        }

        private void menuItemExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void menuItemAbout_Click(object sender, RoutedEventArgs e)
        {
            WinAbout win = new WinAbout();
            win.ShowDialog();
        }

    }
}
