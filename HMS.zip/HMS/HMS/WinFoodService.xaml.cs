﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using ClassLibrary;

namespace HMS
{
    /// <summary>
    /// Interaction logic for WinFoodService.xaml
    /// </summary>
    public partial class WinFoodService : Window
    {
        private bool PassValue
        { get; set; }
        public WinFoodService()
        {
            InitializeComponent();
            FoodService fs = new FoodService();
            fs.View();       
        }

        public WinFoodService(bool passValue)
        {
            InitializeComponent();
            DBAccess.Initialize();
            this.PassValue = passValue;
        }


        public string FoodServiceId
        {
            get 
            {
                if (grdFoodService.SelectedIndex >= 0)
                {
                    FoodService foodService = (FoodService)grdFoodService.SelectedItem;
                    return foodService.Id.ToString();
                }
                else
                    return string.Empty;
                
            }
        }

        public string FoodServiceType
        {
            get 
            {
                if (grdFoodService.SelectedIndex >= 0)
                {
                    FoodService foodService = (FoodService)grdFoodService.SelectedItem;
                    return foodService.Type;
                }
                else
                    return string.Empty;
            }
        }

        private string SuccessMessage
        {
            get { return GlobalAccess.SuccessfulMessage() + this.Title; }
        }

        private string ErrorMessage
        {
            get { return GlobalAccess.ErrorMessage() + this.Title; }
        }


        private void btnView_Click(object sender, RoutedEventArgs e)
        {
            FoodService foodService = new FoodService();
            foodService.View();

            if (DBAccess.ExceptionExist())
                MessageBox.Show(DBAccess.ExceptionMessage, ErrorMessage, MessageBoxButton.OK, MessageBoxImage.Exclamation);
            else
            {
                //grdStaff.DataContext;
                grdFoodService.ItemsSource = FoodService.Collection;
            }
        }

        private void grdRoomService_Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            FoodService foodService = (FoodService)grdFoodService.SelectedItem;
            //MessageBox.Show(staff.FirstName);

            if (MessageBox.Show("Are you sure want to delete this currently selected food service ?",
                this.Title, MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                foodService.Delete();

                if (DBAccess.ExceptionExist())
                    MessageBox.Show(DBAccess.ExceptionMessage, ErrorMessage, MessageBoxButton.OK, MessageBoxImage.Exclamation);
                else
                {
                    FoodService.Collection.Remove(foodService);
                    MessageBox.Show("The current food service has been successfully deleted.", SuccessMessage, MessageBoxButton.OK, MessageBoxImage.Information);                    
                }

            }
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            WinFoodServiceAdd win = new WinFoodServiceAdd();
            win.ShowDialog();
        }

        private void grdFoodService_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if(PassValue==true)
            {
                this.Close();
                return;
            }

            EditFoodService(); 
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            EditFoodService();
        }

        private void EditFoodService()
        {
            if (grdFoodService.SelectedIndex >= 0)
            {
                FoodService foodService = (FoodService)grdFoodService.SelectedItem;
                WinFoodServiceUpdate win = new WinFoodServiceUpdate(foodService.Id);
                win.ShowDialog();

            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }
    }
}
