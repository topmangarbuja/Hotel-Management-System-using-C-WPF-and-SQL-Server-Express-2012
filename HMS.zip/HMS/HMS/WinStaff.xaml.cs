﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using System.Data;
using System.Data.SqlClient;
using ClassLibrary;
using System.Collections.ObjectModel;

namespace HMS
{
    /// <summary>
    /// Interaction logic for WindowStaff.xaml
    /// </summary>
    public partial class WinStaff : Window
    {
        //public static ObservableCollection<Staff> staffs;

        public WinStaff()
        {
            InitializeComponent();
            Staff s = new Staff();
            s.View();
        }

        public string SuccessMessage
        {
            get
            {
                return GlobalAccess.SuccessfulMessage() + this.Title;
            }
        }

        public string ErrorMessage
        {
            get
            {
                return GlobalAccess.ErrorMessage() + this.Title;
            }
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            WinStaffAdd win = new WinStaffAdd();
            win.ShowDialog();
        }

        private void btnView_Click(object sender, RoutedEventArgs e)
        {
           // SqlCommand command = new SqlCommand();
            //command.CommandText = "SELECT staffId,pword,firstName,lastName,dateOfBirth,gender,phoneNumber,emailAddresss,dateOfJoin,dateOfLeave,isManager,isLogin FROM STAFF";
            //Staff.Select(command);

            //staffs = Staff.GetStaffs();

            Staff staff = new Staff();
            staff.View();

            if (DBAccess.ExceptionExist())
                MessageBox.Show(DBAccess.ExceptionMessage, ErrorMessage, MessageBoxButton.OK, MessageBoxImage.Exclamation);
            else
            {
                //grdStaff.DataContext;
                grdStaff.ItemsSource = Staff.Collection ;                
            }
        }


        private void grdStaff_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if(grdStaff.SelectedIndex>=0)
            {

                Staff staff = (Staff)grdStaff.SelectedItem;
                string id = staff.Id;
                WinStaffUpdate winStaffUpdate = new WinStaffUpdate(id);
                winStaffUpdate.ShowDialog();
            }
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            grdStaff_MouseDoubleClick(null, null);
        }

        private void grdStaff_Hyperlink_Click(object sender,RoutedEventArgs e)
        {
            Staff staff=(Staff)grdStaff.SelectedItem;
            //MessageBox.Show(staff.FirstName);

            if(MessageBox.Show("Are you sure want to delete this currently selected staff: " + staff.Id + staff.FirstName + "?",
                this.Title,MessageBoxButton.YesNo,MessageBoxImage.Question)==MessageBoxResult.Yes)
            {
                staff.Delete();

                if (DBAccess.ExceptionExist())
                    MessageBox.Show(DBAccess.ExceptionMessage, ErrorMessage, MessageBoxButton.OK, MessageBoxImage.Exclamation);
                else
                {
                    MessageBox.Show("The current user has been successfully deleted.", SuccessMessage, MessageBoxButton.OK, MessageBoxImage.Information);
                    Staff.Collection.Remove(staff);
                }
                
            }
        }
    }
}
