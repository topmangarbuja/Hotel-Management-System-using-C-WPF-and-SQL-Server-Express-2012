﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using Microsoft.Win32;
using ClassLibrary;

namespace HMS
{
    /// <summary>
    /// Interaction logic for WinBackupRestore.xaml
    /// </summary>
    public partial class WinRestore : Window
    {
        string fileName;
        public WinRestore()
        {
            InitializeComponent();
        }

        private void btnBrowseRestoreFile_Click(object sender, RoutedEventArgs e)
        {           
            OpenFileDialog dialog = new OpenFileDialog();            
            if (System.IO.Directory.Exists(DBAccess.BackupPath))
                dialog.InitialDirectory = DBAccess.BackupPath;
            else
                dialog.InitialDirectory = @"C:\";

            dialog.DefaultExt = ".bak";
            dialog.Filter = "Bak Files (*.bak)|*.bak";
            dialog.Multiselect=false;

            if(dialog.ShowDialog()==true)
            {
                fileName = dialog.FileName;
                txtFileName.Text = fileName;
                
            }
        }

        private void btnRestore_Click(object sender, RoutedEventArgs e)
        {
            if(string.IsNullOrEmpty(txtFileName.Text))
            {
                MessageBox.Show("Please select backup file.", this.Title, MessageBoxButton.OK, MessageBoxImage.Exclamation);
                return;
            }

            if (MessageBox.Show("Are you sure want to restore database?", this.Title, MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;

            DBAccess.RestoreDatabase(fileName);

            if (DBAccess.ExceptionExist())
            {
                MessageBox.Show(DBAccess.ExceptionMessage, "Error | " + this.Title, MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                    MessageBox.Show("Successfully restored.", this.Title, MessageBoxButton.OK, MessageBoxImage.Information);

            }


        }
    }
}
