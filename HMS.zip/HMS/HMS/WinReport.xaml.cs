﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


using CrystalDecisions.CrystalReports;
using CrystalDecisions.CrystalReports.ViewerObjectModel;
using SAPBusinessObjects.WPF.Viewer;

namespace HMS
{
    /// <summary>
    /// Interaction logic for WinReport.xaml
    /// </summary>
    public partial class WinReport : Window
    {
        public WinReport()
        {
            InitializeComponent();
            
        }
        
        public CrystalReportsViewer report
        {
            get
            {
                return CrystalReportsViewer1;
            }
        }
        
    }
}
