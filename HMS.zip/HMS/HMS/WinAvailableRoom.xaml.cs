﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using ClassLibrary;

namespace HMS
{
    /// <summary>
    /// Interaction logic for WinAvailableRoom.xaml
    /// </summary>
    public partial class WinAvailableRoom : Window
    {
        Room room;
        public WinAvailableRoom()
        {
            InitializeComponent();
            room = new Room();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            room.GetAvailableRooms();

            grdAvailableRoom.ItemsSource = Room.Collection;
        }


        public int RoomNo
        {
            get
            {
                Room room = (Room)grdAvailableRoom.SelectedItem;
                return room.RoomNo;
            }
        }

        public string RoomType
        {
            get
            {
                Room room = (Room)grdAvailableRoom.SelectedItem;
                return room.Type;
            }
        }

        private void grdAvailableRoom_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            this.Close();
            return;
        }
    }
}
