﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using ClassLibrary;
using CrystalDecisions.CrystalReports.Engine;

namespace HMS
{
    /// <summary>
    /// Interaction logic for WinReports.xaml
    /// </summary>
    public partial class WinReports : Window
    {   
        ReportDocument report;
        WinReport a;
               
        public WinReports()
        {
            InitializeComponent();
                
        }

        private void btnCustomer_Click(object sender, RoutedEventArgs e)
        {
            get_Report(sender, e);
        }

        private void get_Report(object sender, RoutedEventArgs e)
        {
            report = new ReportDocument();
            a = new WinReport();
            string path = "";
            Button b = (Button)sender;
            
            if (b == btnCustomer)
                path = GlobalAccess.reportPath+"\\Customer.rpt";
            else if (b == btnStaff)
                path = GlobalAccess.reportPath + "\\Staff.rpt";
            else if(b==btnRoom)
                path = GlobalAccess.reportPath + "\\Room.rpt";
            else if (b == btnRoomService)
                path = GlobalAccess.reportPath + "\\RoomService.rpt";
            else if (b == btnFoodService)
                path = GlobalAccess.reportPath + "\\FoodService.rpt";
            else if (b == btnBook)
                path = GlobalAccess.reportPath + "\\Book.rpt";
            else if (b == btnBill)
                path = GlobalAccess.reportPath + "\\Bill.rpt";

            try
            {
                report.Load(path);
                report.DataSourceConnections[0].SetConnection(DBAccess.ServerName, "HMS", DBAccess.UserId, DBAccess.Password);
                report.SetDatabaseLogon(DBAccess.UserId, DBAccess.Password);
                report.VerifyDatabase();                
                a.CrystalReportsViewer1.ViewerCore.ReportSource = report;
                a.Show();
            }
            catch(Exception err)
            {
                MessageBox.Show(err.Message, this.Title, MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }            
        }
    }
}
