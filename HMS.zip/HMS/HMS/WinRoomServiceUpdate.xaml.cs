﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using ClassLibrary;

namespace HMS
{
    /// <summary>
    /// Interaction logic for WinRoomServiceUpdate.xaml
    /// </summary>
    public partial class WinRoomServiceUpdate : Window
    {
        private RoomService roomService;

        public WinRoomServiceUpdate(int serviceId)
        {
            InitializeComponent();
            roomService = new RoomService();
            roomService.PreviousId = serviceId;
            
        }

        private string SuccessMessage
        {
            get { return GlobalAccess.SuccessfulMessage() + this.Title; }
        }

        private string ErrorMessage
        {
            get { return GlobalAccess.ErrorMessage() + this.Title; }
        }


        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            foreach (RoomService rs in RoomService.Collection)
            {
                if (!cboType.Items.Contains(rs.Type))
                    cboType.Items.Add(rs.Type);
            }


            var filtered = from RoomService rs in RoomService.Collection
                           where rs.Id == roomService.PreviousId
                           select rs;

            foreach (RoomService r in filtered)
            {
                txtServiceId.Text = r.Id.ToString();

                cboType.Text = r.Type;

                txtPrice.Text = r.Price.ToString();
                txtDescription.Text=r.Description;
                break;
            }
        }


        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            roomService.Id = Convert.ToInt32(txtServiceId.Text);
            roomService.Type = cboType.Text;
            roomService.Price = Convert.ToDecimal(txtPrice.Text);
            roomService.Description = txtDescription.Text;

            roomService.Update();

            if (DBAccess.ExceptionExist())
                MessageBox.Show(DBAccess.ExceptionMessage, ErrorMessage, MessageBoxButton.OK, MessageBoxImage.Exclamation);
            else
            {
                //Room.Collection.Remove(room);
                MessageBox.Show("The room service details updated successfully.", SuccessMessage, MessageBoxButton.OK, MessageBoxImage.Information);
                this.Close();
                //Room.Collection.Add(room);
            }
        }

    }
}
