﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using ClassLibrary;

namespace HMS
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class Login : Window
    {
        public Login()
        {
            InitializeComponent();
            DBAccess.Initialize();
            
        }


        private void Login_Loaded(object sender, RoutedEventArgs e)
        {
            
            /*
            if (DBAccess.HasConnection())
                MessageBox.Show("Successful");
            else
                MessageBox.Show("Error");
             */          
        }

        private void btnOk_Click(object sender, RoutedEventArgs e)
        {            
            Staff.Login(txtUsername.Text, txtPassword.Password);
            if (DBAccess.ExceptionExist())
            {
                MessageBox.Show(DBAccess.ExceptionMessage, this.Title, MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {                
                if(GlobalAccess.IsPasswordCorrect)
                {
                    if(GlobalAccess.IsLogin)
                    {
                        Main win = new Main();
                        this.Hide();
                        win.ShowDialog();                    
                    }
                    else
                        MessageBox.Show("Your access is denied. Please contact administrator.",this.Title,MessageBoxButton.OK,MessageBoxImage.Exclamation);   
                }                    
                else
                    MessageBox.Show("Incorrect username or password. Please try again.", this.Title, MessageBoxButton.OK, MessageBoxImage.Error); 
                
            }
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
