﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using ClassLibrary;

namespace HMS
{
    /// <summary>
    /// Interaction logic for WinFoodServiceUpdate.xaml
    /// </summary>
    public partial class WinFoodServiceUpdate : Window
    {
        private FoodService foodService;
        private FoodService prevFoodService;
        public WinFoodServiceUpdate(int serviceId)
        {
            InitializeComponent();
            foodService = new FoodService();
            foodService.PreviousId = serviceId;
            
        }

        private string SuccessMessage
        {
            get { return GlobalAccess.SuccessfulMessage() + this.Title; }
        }

        private string ErrorMessage
        {
            get { return GlobalAccess.ErrorMessage() + this.Title; }
        }


        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            foreach (FoodService fs in FoodService.Collection)
            {
                if (!cboType.Items.Contains(fs.Type))
                    cboType.Items.Add(fs.Type);
            }

            var filtered = from FoodService fs in FoodService.Collection
                           where fs.Id == foodService.PreviousId
                           select fs;

            foreach (FoodService r in filtered)
            {
                txtServiceId.Text = r.Id.ToString();

               cboType.Text=r.Type;

                txtPrice.Text = r.Price.ToString();
                txtDescription.Text=r.Description;

                prevFoodService = r;
                break;
            }
        }


        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            foodService.Id = Convert.ToInt32(txtServiceId.Text);
            foodService.Type = cboType.Text;
            foodService.Price = Convert.ToDecimal(txtPrice.Text);
            foodService.Description = txtDescription.Text;

            foodService.Update();

            if (DBAccess.ExceptionExist())
                MessageBox.Show(DBAccess.ExceptionMessage, ErrorMessage, MessageBoxButton.OK, MessageBoxImage.Exclamation);
            else
            {
                FoodService.Collection.Remove(prevFoodService);
                FoodService.Collection.Add(foodService);
                MessageBox.Show("The food service details has updated successfully.", SuccessMessage, MessageBoxButton.OK, MessageBoxImage.Information);
                this.Close();
                
            }
        }

    }
}
