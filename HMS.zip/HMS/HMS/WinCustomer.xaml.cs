﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using ClassLibrary;

namespace HMS
{
    /// <summary>
    /// Interaction logic for WinCustomer.xaml
    /// </summary>
    public partial class WinCustomer : Window
    {
        private bool PassValue
        { get; set; }
        public WinCustomer()
        {
            InitializeComponent();
            Customer c = new Customer();
            c.View();
        }


        public WinCustomer(bool passValue)
        {
            InitializeComponent();
            DBAccess.Initialize();
            this.PassValue = passValue;
        }

        public string CustomerId
        {
            get
            {
                if(grdCustomer.SelectedIndex>=0)
                {
                    Customer customer = (Customer)grdCustomer.SelectedItem;
                    return customer.Id;
                }
                else
                {
                    return string.Empty;
                }
                
            }
        }

        public string CustomerName
        {
            get
            {
                if(grdCustomer.SelectedIndex>=0)
                {
                    Customer customer = (Customer)grdCustomer.SelectedItem;
                    return customer.FirstName + " " + customer.LastName;
                }
                else
                {
                    return string.Empty;
                }
                
            }
        }

        private string SuccessMessage
        {
            get { return GlobalAccess.SuccessfulMessage() + this.Title; }
        }

        private string ErrorMessage
        {
            get { return GlobalAccess.ErrorMessage() + this.Title; }
        }

        private void btnView_Click(object sender, RoutedEventArgs e)
        {
            Customer cust = new Customer();
            cust.View();

            if (DBAccess.ExceptionExist())
                MessageBox.Show(DBAccess.ExceptionMessage, ErrorMessage, MessageBoxButton.OK, MessageBoxImage.Exclamation);
            else
                grdCustomer.ItemsSource = Customer.Collection;
        }
        
        private void grdCustomer_Hyperlink_Click(object sender,RoutedEventArgs e)
        {
            if(MessageBox.Show("Are you sure want to delete this customer?",this.Title,MessageBoxButton.YesNo,
                MessageBoxImage.Question)==MessageBoxResult.Yes)
            {
                Customer customer = (Customer)grdCustomer.SelectedItem;
                customer.Delete();

                if (DBAccess.ExceptionExist())
                    MessageBox.Show(DBAccess.ExceptionMessage, ErrorMessage, MessageBoxButton.OK, MessageBoxImage.Exclamation);
                else
                {
                    MessageBox.Show("The customer data has been successfully deleted.", SuccessMessage, MessageBoxButton.OK, MessageBoxImage.Information);
                    Customer.Collection.Remove(customer);
                }                    
            }
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            WinCustomerAdd win = new WinCustomerAdd();
            win.ShowDialog();
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            EditCustomer();
        }

        private void grdCustomer_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if(PassValue)
            {
                this.Close();
                return;
            }

            EditCustomer();
        }

        private void EditCustomer()
        {
            if (grdCustomer.SelectedIndex >= 0)
            {
                Customer customer = (Customer)grdCustomer.SelectedItem;
                WinCustomerUpdate win = new WinCustomerUpdate(customer.Id);
                win.ShowDialog();
            }
        }
    }
}
